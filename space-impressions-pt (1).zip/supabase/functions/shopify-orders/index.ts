import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const SHOPIFY_API_VERSION = "2025-07";

const ORDERS_QUERY = `
  query CustomerOrders($query: String!) {
    orders(first: 50, query: $query, sortKey: CREATED_AT, reverse: true) {
      edges {
        node {
          id
          name
          createdAt
          displayFinancialStatus
          displayFulfillmentStatus
          statusPageUrl
          currentTotalPriceSet { shopMoney { amount currencyCode } }
          fulfillments(first: 5) {
            trackingInfo(first: 3) { number url company }
          }
          lineItems(first: 25) {
            edges {
              node {
                title
                quantity
                variantTitle
                originalTotalSet { shopMoney { amount currencyCode } }
                image { url }
              }
            }
          }
        }
      }
    }
  }
`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return json({ error: "unauthorized" }, 401);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userError } = await supabase.auth.getUser();
    const email = userData?.user?.email;
    if (userError || !email) {
      return json({ error: "unauthorized" }, 401);
    }

    const domain = Deno.env.get("SHOPIFY_STORE_DOMAIN");
    const token = Deno.env.get("SHOPIFY_ACCESS_TOKEN");
    if (!domain || !token) {
      return json({ orders: [], warning: "shopify_not_configured" });
    }

    const response = await fetch(
      `https://${domain}/admin/api/${SHOPIFY_API_VERSION}/graphql.json`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Shopify-Access-Token": token,
        },
        body: JSON.stringify({
          query: ORDERS_QUERY,
          variables: { query: `email:${email}` },
        }),
      },
    );

    if (!response.ok) {
      console.error("shopify http error", response.status);
      return json({ orders: [], warning: "shopify_unavailable" });
    }

    const payload = await response.json();
    if (payload.errors) {
      console.error("shopify graphql error", JSON.stringify(payload.errors));
      return json({ orders: [], warning: "shopify_permission" });
    }

    const orders = (payload.data?.orders?.edges ?? []).map((edge: any) => {
      const n = edge.node;
      const tracking = (n.fulfillments ?? []).flatMap((f: any) => f.trackingInfo ?? []);
      return {
        id: n.id,
        name: n.name,
        createdAt: n.createdAt,
        financialStatus: n.displayFinancialStatus,
        fulfillmentStatus: n.displayFulfillmentStatus,
        statusUrl: n.statusPageUrl,
        total: n.currentTotalPriceSet?.shopMoney?.amount ?? "0",
        currency: n.currentTotalPriceSet?.shopMoney?.currencyCode ?? "EUR",
        tracking,
        items: (n.lineItems?.edges ?? []).map((li: any) => ({
          title: li.node.title,
          variantTitle: li.node.variantTitle,
          quantity: li.node.quantity,
          total: li.node.originalTotalSet?.shopMoney?.amount ?? "0",
          currency: li.node.originalTotalSet?.shopMoney?.currencyCode ?? "EUR",
          image: li.node.image?.url ?? null,
        })),
      };
    });

    return json({ orders });
  } catch (error) {
    console.error("shopify-orders error", error);
    return json({ error: "internal_error" }, 500);
  }
});
