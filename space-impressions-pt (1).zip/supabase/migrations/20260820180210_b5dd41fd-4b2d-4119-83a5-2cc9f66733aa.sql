CREATE TABLE public.meeting_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  company_name TEXT,
  project_type TEXT,
  description TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'meet',
  preferred_date DATE NOT NULL,
  preferred_time TEXT NOT NULL,
  alternative_date DATE,
  alternative_time TEXT,
  status TEXT NOT NULL DEFAULT 'pendente',
  meeting_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT INSERT ON public.meeting_requests TO anon;
GRANT SELECT, INSERT ON public.meeting_requests TO authenticated;
GRANT ALL ON public.meeting_requests TO service_role;

ALTER TABLE public.meeting_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can request a meeting"
ON public.meeting_requests FOR INSERT
TO anon, authenticated
WITH CHECK (user_id IS NULL OR user_id = auth.uid());

CREATE POLICY "Users can view their own meeting requests"
ON public.meeting_requests FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE TRIGGER update_meeting_requests_updated_at
BEFORE UPDATE ON public.meeting_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();