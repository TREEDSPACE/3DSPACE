# Atualização visual 2026

- [x] Analisar a família de logótipos e preservar fontes, cores e estrutura.
- [x] Aplicar os logótipos oficiais e a linguagem gráfica nas páginas existentes.
- [x] Verificar o resultado nos temas claro e escuro e em ecrãs estreitos.
- [x] Deixar o padrão de marca numa só cor: branco em modo escuro, preto em modo claro.
- [x] Repor os três traços no padrão, desenhados lado a lado com a curva na mesma cor.

# Código para Shopify Sidekick

- [x] Preparar código Liquid, estilos e instruções para recriar as páginas do site no Shopify.
- [x] Verificar sintaxe e início localmente; entregar código, logótipos oficiais e limitações. Publicação e testes reais na Shopify ficam a cargo da instalação na loja.