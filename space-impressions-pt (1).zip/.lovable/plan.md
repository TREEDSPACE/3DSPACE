
# Brand Kit Overhaul — 3D Space

Translate the official brand kit (preto / grafite / cinza / branco gelo + lima neon `#D4FF00`) into a living design system across every page. The current site is fully greyscale and missing the signature lime accent, the bold display typography, the diagonal arrow motif, and the deliberate black/white rhythm shown in the kit.

## Defaults I'm taking

- **Display font**: Archivo Black (Google Fonts, free) for hero impact titles — closest to the chunky rounded "KIT DE MARCA" feel without licensing risk. Space Grotesk stays as secondary heading + UI. Inter stays as body.
- **Lime intensity**: medium-high (≈7/10) — used on CTAs, arrow motifs, hover states, key highlights, hairline accents, focus rings, and one accent block per major section. Never as primary background of large surfaces.
- **White sections**: deliberate rhythm — Featured Products on homepage, Sobre (mission/story), Indústrias on Empresas (already white). Catalog stays dark.
- **Scope**: full refresh — design tokens + shared components + every page. Index gets the most love.

## Design system updates

### `src/index.css` + `tailwind.config.ts`
- Add HSL tokens:
  - `--brand-black: 0 0% 4%` (#0A0A0A)
  - `--brand-graphite: 0 0% 17%` (#2B2B2B)
  - `--brand-grey: 0 0% 55%` (#8C8C8C)
  - `--brand-ice: 60 14% 96%` (#F5F5F3)
  - `--brand-lime: 71 100% 50%` (#D4FF00) → exposed as `--accent-lime`
- Repoint `--background`, `--card`, `--muted`, `--border` to brand greys; keep `--accent` as lime for CTAs.
- Add `.section-white` (uses `--brand-ice`) and `.section-black` utilities; refine `.label-tag` to use lime border + lime text variant.
- Import Archivo Black via Google Fonts; expose as `font-display` in Tailwind.

### Typography scale
- `font-display` (Archivo Black) → hero H1 only, very large, tight tracking.
- `font-heading` (Space Grotesk) → section H2/H3, uppercase tracked.
- `font-body` (Inter) → paragraphs, UI.

## New / updated shared components

1. **`BrandArrow.tsx`** — diagonal lime SVG arrow (↘) used as section transition cue and decorative element. Variants: size, rotation, color.
2. **`TechLabel.tsx`** — small monospaced corner tag (e.g. `@3D.SPACE_OFFICIAL`, `[ 01 / 06 ]`, `// SECTION_ID`) placed top-right of major sections.
3. **`SectionLabel.tsx`** — extend with `variant="lime"` for lime-bordered chip.
4. **`Button` (variants)** — add `lime` variant: lime bg + black text + black hover; ensure outline variant has lime hover state.
5. **`GeometricFrame.tsx`** — add optional lime corner accents and a lime hairline option.
6. **`GridPattern.tsx`** — add `accent="lime"` prop for occasional lime grid lines on dark sections.
7. **`MonochromeImage.tsx`** (new) — wrapper that applies `grayscale contrast-110` filter so all imagery feels B&W industrial like the kit.

## Page-by-page changes

### Header / Footer
- Logo unchanged (already correct white version).
- Active nav link: lime underline animation on hover + active route.
- Cart icon: lime dot badge for item count.
- Footer: thin lime hairline divider above copyright; lime hover on links; small `[ 3D.SPACE / EST. ]` tech label.

### `Index.tsx` (homepage)
- **Hero**: black bg, Archivo Black display H1 (very large), grey subtitle, primary CTA = lime button, secondary = outline white. Add diagonal lime arrow motif bottom-right. Tech label top-right (`// 01 — INTRO`). Background grid stays.
- **O Que Fazemos** (flip cards): keep flip cards; add lime hairline accent on front bottom edge; PagePeel corner gets a faint lime glow on hover; section gets a lime arrow + tech label.
- **Featured Products**: SWITCH TO WHITE SECTION (`.section-white`). Black product cards on white bg create the kit's signature contrast. Lime accent on "Ver todos" CTA.
- **About teaser**: dark, B&W image inside GeometricFrame with lime corner accents.
- **Stats**: dark, numbers in Archivo Black, lime separator lines between stats.
- **B2B CTA band**: full-bleed dark with lime arrow + lime button.

### `Servicos.tsx`
- Hero matches Index style.
- Alternate dark / white sections every other block to create rhythm.
- Service detail cards on white: black border, lime icon accent on hover.
- Process steps: numbered with Archivo Black huge numerals, lime connector line.

### `Produtos.tsx`
- Stays dark (catalog needs the contrast for product photos).
- Filter pills: lime active state, lime focus ring.
- Product cards: lime "Add to cart" hover; price in lime on hover.
- Tech label `// CATALOG` top-right.

### `ProductDetail.tsx`
- Two-column: B&W product image left (MonochromeImage off here so real photo shows), info right.
- Lime "Adicionar ao Carrinho" CTA. Lime price highlight if on sale.
- Specs table with lime hairline rows.

### `Sobre.tsx`
- Hero dark with display font.
- Mission section WHITE — black text, black B&W photo with GeometricFrame.
- Values grid: dark cards with lime icon top-left, grid pattern bg.
- Timeline / story: alternating black/white rows.

### `Empresas.tsx`
- Industries section already white — keep, but cards get lime icon accent on hover.
- Benefits: lime checkmarks instead of white; lime CTA button.
- Hero: tech label, lime arrow.

### `Contacto.tsx`
- Split: dark left (intro + contact info with lime icons), white right (form).
- Form inputs: black border, lime focus ring, lime submit button.

### `CartDrawer.tsx`
- Dark drawer; lime accent on subtotal and checkout CTA.

## Imagery treatment
- Apply `MonochromeImage` wrapper to hero/about/business photos so site feels cohesive with kit's B&W industrial photography. Product photos remain in color.

## Mobile considerations
- Display font H1 scales to ~`text-4xl` on mobile (down from `text-7xl`).
- Lime accents stay visible (high contrast meets WCAG AA on black).
- Tech labels hidden below `md` to avoid clutter.
- White sections preserve full-bleed at all breakpoints.

## Out of scope
- No backend / data changes.
- No Shopify integration changes.
- No new pages.
- No new dependencies beyond a Google Font import.

## Technical Details

```text
tokens (HSL)
├── --brand-black     0 0% 4%     #0A0A0A
├── --brand-graphite  0 0% 17%    #2B2B2B
├── --brand-grey      0 0% 55%    #8C8C8C
├── --brand-ice      60 14% 96%   #F5F5F3
└── --brand-lime     71 100% 50%  #D4FF00   → --accent

fonts
├── font-display  → "Archivo Black" (Google)
├── font-heading  → "Space Grotesk"
└── font-body     → "Inter"

new components
├── src/components/BrandArrow.tsx
├── src/components/TechLabel.tsx
└── src/components/MonochromeImage.tsx

updated
├── src/index.css                (tokens, utilities, font import)
├── tailwind.config.ts           (font-display, brand-* colors)
├── src/components/ui/button.tsx (lime variant)
├── src/components/SectionLabel.tsx (lime variant)
├── src/components/GeometricFrame.tsx (lime corners)
├── src/components/GridPattern.tsx (lime variant)
├── src/components/Header.tsx, Footer.tsx
├── src/components/ServiceFlipCard.tsx
├── src/components/CartDrawer.tsx
└── src/pages/* (all 7 pages)
```

## Suggested build order

1. Tokens + fonts + Tailwind config (foundation).
2. New shared components (BrandArrow, TechLabel, MonochromeImage) + Button lime variant.
3. Header / Footer.
4. Index.tsx (showcase page).
5. Sobre, Empresas, Servicos.
6. Produtos, ProductDetail, Contacto, CartDrawer.
7. QA pass on mobile + desktop, verify lime contrast, fix overflows.
