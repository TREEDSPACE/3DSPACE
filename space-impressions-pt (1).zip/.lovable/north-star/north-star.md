<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Pessoas em Portugal recebem as peças impressas em 3D que querem

## Métrica

Encomendas concluídas no checkout da Shopify por semana
