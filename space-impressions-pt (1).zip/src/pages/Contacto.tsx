import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Clock, Loader2, Video } from "lucide-react";
import { Link } from "react-router-dom";

import { z } from "zod";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandPattern from "@/components/BrandPattern";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const copy = {
  pt: {
    validation: {
      name: "Indique o seu nome",
      email: "Email inválido",
      message: "Descreva o seu pedido",
    },
    serviceLabels: {
      impressao: "Impressão 3D Personalizada",
      modelacao: "Modelação 3D",
      prototipagem: "Prototipagem",
      produtos: "Produtos",
      empresas: "Soluções para Empresas",
      outro: "Outro",
    },
    sendError: "Não foi possível enviar o pedido. Tente novamente.",
    sendSuccess: "Pedido enviado. Entraremos em contacto brevemente.",
    label001: "Contacto",
    titleA: "Fale",
    titleB: "Connosco",
    subtitle: "Tem um projeto em mente? Entre em contacto e teremos todo o gosto em ajudar.",
    sendMessageTitle: "Envie-nos uma Mensagem",
    name: "Nome",
    namePh: "O seu nome",
    email: "Email",
    emailPh: "o.seu@email.com",
    phone: "Telefone",
    phonePh: "+351 900 000 000",
    serviceType: "Tipo de Serviço",
    serviceTypePh: "Selecione um serviço",
    message: "Mensagem",
    messagePh: "Descreva o seu projeto ou pedido...",
    sendMessage: "Enviar Mensagem",
    scheduleCall: "Marcar videochamada",
    infoTitle: "Informações",
    email2: "geral.3dspace@gmail.com",
    phone2: "+351 931 060 445",
    location: "Lisboa, Portugal",
    hours: "Seg-Sex: 9h-18h",
    mapSoon: "Mapa (em breve)",
  },
  en: {
    validation: {
      name: "Please enter your name",
      email: "Invalid email",
      message: "Please describe your request",
    },
    serviceLabels: {
      impressao: "Custom 3D Printing",
      modelacao: "3D Modelling",
      prototipagem: "Prototyping",
      produtos: "Products",
      empresas: "Business Solutions",
      outro: "Other",
    },
    sendError: "Could not send your request. Please try again.",
    sendSuccess: "Request sent. We'll get back to you shortly.",
    label001: "Contact",
    titleA: "Talk",
    titleB: "To Us",
    subtitle: "Have a project in mind? Get in touch and we'll be glad to help.",
    sendMessageTitle: "Send Us a Message",
    name: "Name",
    namePh: "Your name",
    email: "Email",
    emailPh: "your@email.com",
    phone: "Phone",
    phonePh: "+351 900 000 000",
    serviceType: "Service Type",
    serviceTypePh: "Select a service",
    message: "Message",
    messagePh: "Describe your project or request...",
    sendMessage: "Send Message",
    scheduleCall: "Schedule a video call",
    infoTitle: "Information",
    email2: "geral.3dspace@gmail.com",
    phone2: "+351 931 060 445",
    location: "Lisbon, Portugal",
    hours: "Mon-Fri: 9am-6pm",
    mapSoon: "Map (coming soon)",
  },
};

const Contacto = () => {
  const c = useCopy(copy);
  const { user } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", phone: "", service: "", message: "" });
  const [sending, setSending] = useState(false);

  const quoteSchema = z.object({
    name: z.string().trim().min(1, { message: c.validation.name }).max(100),
    email: z.string().trim().email({ message: c.validation.email }).max(255),
    phone: z.string().trim().max(30).optional(),
    service: z.string().trim().max(60).optional(),
    message: z.string().trim().min(5, { message: c.validation.message }).max(2000),
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = quoteSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSending(true);
    const { error } = await supabase.from("quote_requests").insert({
      user_id: user?.id ?? null,
      name: parsed.data.name,
      email: parsed.data.email,
      phone: parsed.data.phone || null,
      service: parsed.data.service ? c.serviceLabels[parsed.data.service as keyof typeof c.serviceLabels] ?? parsed.data.service : null,
      message: parsed.data.message,
    });
    setSending(false);
    if (error) {
      toast.error(c.sendError);
      return;
    }
    toast.success(c.sendSuccess);
    setForm({ name: "", email: "", phone: "", service: "", message: "" });
  };

  return (

  <div className="min-h-screen bg-background lg:pl-56">
    <Header />

    <section className="pt-24 pb-12 section-dark relative overflow-hidden">
      <GridPattern />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
          <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.label001}</SectionLabel></motion.div>
          <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
            {c.titleA} <span className="lime-text">{c.titleB}</span>
          </motion.h1>
          <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
            {c.subtitle}
          </motion.p>
        </motion.div>
      </div>
    </section>

    {/* Form - WHITE */}
    <section className="py-20 md:py-24 section-white relative overflow-hidden">
      <BrandPattern tone="dark" opacity={0.11} size={300/2} fade="bottom" />
      <div className="container mx-auto px-4 md:px-6">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-3 gap-12 md:gap-16">
          <motion.div variants={fadeUp} className="lg:col-span-2">
            <h2 className="text-xl md:text-2xl font-heading font-bold uppercase mb-8 text-black">{c.sendMessageTitle}</h2>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name" className="text-black">{c.name}</Label>
                  <Input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={c.namePh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                </div>
                <div>
                  <Label htmlFor="email" className="text-black">{c.email}</Label>
                  <Input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder={c.emailPh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="phone" className="text-black">{c.phone}</Label>
                  <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder={c.phonePh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                </div>
                <div>
                  <Label htmlFor="service" className="text-black">{c.serviceType}</Label>
                  <Select value={form.service} onValueChange={(v) => setForm({ ...form, service: v })}>
                    <SelectTrigger id="service" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                      <SelectValue placeholder={c.serviceTypePh} />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(c.serviceLabels).map(([value, label]) => (
                        <SelectItem key={value} value={value}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="message" className="text-black">{c.message}</Label>
                <Textarea id="message" required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder={c.messagePh} className="mt-2 min-h-[150px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
              </div>
              <div className="flex flex-wrap items-center gap-4">
                <Button type="submit" size="lg" disabled={sending} className="uppercase tracking-wider font-heading min-h-[48px]">
                  {sending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {c.sendMessage}
                </Button>
                <Button asChild type="button" variant="outline" size="lg" className="uppercase tracking-wider font-heading min-h-[48px] border-black/20 text-black hover:bg-black hover:text-white">
                  <Link to="/marcar-reuniao">
                    <Video className="mr-2 h-4 w-4" /> {c.scheduleCall}
                  </Link>
                </Button>
              </div>

            </form>

          </motion.div>

          <motion.div variants={fadeUp} className="space-y-8">
            <div>
              <h3 className="font-heading font-semibold uppercase tracking-wide mb-4 text-black">{c.infoTitle}</h3>
              <div className="space-y-4 text-sm">
                <a href="mailto:geral.3dspace@gmail.com" className="flex items-center gap-3 text-black/50 hover:text-black transition-colors min-h-[44px]">
                  <Mail size={16} className="text-black" /> {c.email2}
                </a>
                <a href="tel:+351931060445" className="flex items-center gap-3 text-black/50 hover:text-black transition-colors min-h-[44px]">
                  <Phone size={16} className="text-black" /> {c.phone2}
                </a>
                <div className="flex items-center gap-3 text-black/50 min-h-[44px]">
                  <MapPin size={16} className="text-black" /> {c.location}
                </div>
                <div className="flex items-center gap-3 text-black/50 min-h-[44px]">
                  <Clock size={16} className="text-black" /> {c.hours}
                </div>
              </div>
            </div>

            <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
              <span className="text-black/30 text-sm">{c.mapSoon}</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>

      <Footer />
    </div>
  );
};



export default Contacto;
