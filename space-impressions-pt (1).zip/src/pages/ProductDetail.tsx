import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Loader2, ShoppingCart } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import WishlistButton from "@/components/WishlistButton";

import { Skeleton } from "@/components/ui/skeleton";
import { useProductByHandle } from "@/hooks/use-shopify-products";
import { useCartStore } from "@/stores/cartStore";
import { formatPrice } from "@/lib/shopify";
import { toast } from "sonner";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const copy = {
  pt: {
    notFound: "Produto não encontrado.",
    backToProducts: "Voltar aos Produtos",
    addedToCart: "Adicionado ao carrinho",
    variant: "Variante",
    addToCart: "Adicionar ao Carrinho",
    outOfStock: "Este produto está esgotado.",
  },
  en: {
    notFound: "Product not found.",
    backToProducts: "Back to Products",
    addedToCart: "Added to cart",
    variant: "Variant",
    addToCart: "Add to Cart",
    outOfStock: "This product is out of stock.",
  },
};

const ProductDetail = () => {
  const c = useCopy(copy);
  const { handle } = useParams<{ handle: string }>();
  const { data: product, isLoading, error } = useProductByHandle(handle || "");
  const { addItem, isLoading: cartLoading } = useCartStore();
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-24 container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 py-12">
            <Skeleton className="aspect-square rounded-lg" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-12 w-48" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-24 container mx-auto px-4 md:px-6 text-center py-24">
          <p className="text-muted-foreground">{c.notFound}</p>
          <Button asChild className="mt-4">
            <Link to="/produtos">{c.backToProducts}</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const images = product.images.edges;
  const variants = product.variants.edges;
  const selectedVariant = variants[selectedVariantIndex]?.node;
  const hasMultipleVariants = variants.length > 1 && !(variants.length === 1 && variants[0].node.title === "Default Title");

  const handleAddToCart = async () => {
    if (!selectedVariant) return;
    await addItem({
      product: { node: product },
      variantId: selectedVariant.id,
      variantTitle: selectedVariant.title,
      price: selectedVariant.price,
      quantity: 1,
      selectedOptions: selectedVariant.selectedOptions || [],
    });
    toast.success(c.addedToCart, { position: "top-center" });
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      <section className="pt-24 pb-20 md:pb-24 section-light">
        <div className="container mx-auto px-4 md:px-6">
          <Link to="/produtos" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors min-h-[44px]">
            <ArrowLeft size={16} /> {c.backToProducts}
          </Link>

          <motion.div initial="hidden" animate="visible" variants={{ visible: { transition: { staggerChildren: 0.1 } } }} className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12">
            <motion.div variants={fadeUp}>
              <div className="aspect-square overflow-hidden rounded-lg bg-secondary mb-4">
                {images[selectedImageIndex] ? (
                  <img src={images[selectedImageIndex].node.url} alt={images[selectedImageIndex].node.altText || product.title} className="w-full h-full object-cover" />
                ) : (
                  <img src="/placeholder.svg" alt={product.title} className="w-full h-full object-cover" />
                )}
              </div>
              {images.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {images.map((img, i) => (
                    <button key={i} onClick={() => setSelectedImageIndex(i)} className={`w-16 h-16 md:w-20 md:h-20 rounded-md overflow-hidden border-2 transition-colors flex-shrink-0 ${i === selectedImageIndex ? 'border-foreground' : 'border-transparent'}`}>
                      <img src={img.node.url} alt={img.node.altText || ""} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-6">
              {product.productType && (
                <span className="text-xs uppercase tracking-wider text-muted-foreground">{product.productType}</span>
              )}
              <h1 className="text-2xl md:text-4xl font-heading font-bold uppercase">{product.title}</h1>
              <p className="text-xl md:text-2xl text-foreground font-bold">
                {selectedVariant && formatPrice(selectedVariant.price.amount, selectedVariant.price.currencyCode)}
              </p>

              {product.description && (
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              )}

              {hasMultipleVariants && (
                <div>
                  <label className="text-sm font-medium uppercase tracking-wider mb-2 block">{c.variant}</label>
                  <div className="flex flex-wrap gap-2">
                    {variants.map((v, i) => (
                      <button
                        key={v.node.id}
                        onClick={() => setSelectedVariantIndex(i)}
                        disabled={!v.node.availableForSale}
                        className={`px-4 py-2.5 text-sm rounded-full border transition-colors min-h-[44px] ${
                          i === selectedVariantIndex
                            ? 'bg-foreground text-background border-foreground'
                            : v.node.availableForSale
                              ? 'border-border text-muted-foreground hover:border-foreground/50'
                              : 'border-border text-muted-foreground/40 cursor-not-allowed'
                        }`}
                      >
                        {v.node.title}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3">
                <Button
                  onClick={handleAddToCart}
                  disabled={cartLoading || !selectedVariant?.availableForSale}
                  size="lg"
                  className="uppercase tracking-wider font-heading w-full sm:w-auto min-h-[48px]"
                >
                  {cartLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ShoppingCart className="w-4 h-4 mr-2" />}
                  {c.addToCart}
                </Button>
                <WishlistButton
                  className="h-12 w-12"
                  product={{
                    product_handle: product.handle,
                    product_id: product.id,
                    title: product.title,
                    image_url: images[0]?.node.url ?? null,
                    price: parseFloat(product.priceRange.minVariantPrice.amount),
                    currency: product.priceRange.minVariantPrice.currencyCode,
                  }}
                />
              </div>


              {selectedVariant && !selectedVariant.availableForSale && (
                <p className="text-sm text-destructive">{c.outOfStock}</p>
              )}
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ProductDetail;
