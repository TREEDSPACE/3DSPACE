import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GridPattern from "@/components/GridPattern";
import SectionLabel from "@/components/SectionLabel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

const passwordSchema = z.string().min(8, { message: "A palavra-passe deve ter pelo menos 8 caracteres" }).max(72);

const ResetPassword = () => {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = passwordSchema.safeParse(password);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (password !== confirm) {
      toast.error("As palavras-passe não coincidem");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Palavra-passe atualizada");
    navigate("/conta", { replace: true });
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />
      <section className="relative section-dark overflow-hidden pt-32 pb-20 md:pt-40 min-h-screen">
        <GridPattern />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-md mx-auto">
            <div className="text-center">
              <SectionLabel index="[ 001 ]">Segurança</SectionLabel>
              <h1 className="display-h1 text-3xl md:text-5xl mt-4">
                Nova <span className="lime-text">Palavra-passe</span>
              </h1>
            </div>
            <form onSubmit={handleSubmit} className="mt-10 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Nova palavra-passe</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm">Confirmar palavra-passe</Label>
                <Input id="confirm" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full uppercase tracking-wider font-heading min-h-[52px]">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Guardar
              </Button>
            </form>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default ResetPassword;
