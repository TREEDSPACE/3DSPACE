import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { Loader2, LogOut } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GridPattern from "@/components/GridPattern";
import SectionLabel from "@/components/SectionLabel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import OrdersPanel from "@/components/account/OrdersPanel";
import AddressesPanel from "@/components/account/AddressesPanel";
import WishlistPanel from "@/components/account/WishlistPanel";
import QuotesPanel from "@/components/account/QuotesPanel";
import MeetingsPanel from "@/components/account/MeetingsPanel";
import TrainingsPanel from "@/components/account/TrainingsPanel";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

const required = (max: number, label: string) =>
  z.string().trim().min(1, { message: `${label} é obrigatório` }).max(max, { message: `${label} demasiado longo` });

const profileSchema = z.object({
  full_name: required(100, "Nome completo"),
  phone: required(30, "Telefone"),
  nif: z.string().trim().max(20).optional(),
  company_name: z.string().trim().max(120).optional(),
  address: required(200, "Morada"),
  postal_code: required(20, "Código postal"),
  city: required(100, "Localidade"),
  country: required(100, "País"),
});

type ProfileForm = Partial<z.infer<typeof profileSchema>>;

const fields: { key: keyof ProfileForm; label: string; autoComplete?: string; required?: boolean }[] = [
  { key: "full_name", label: "Nome completo", autoComplete: "name", required: true },
  { key: "phone", label: "Telefone", autoComplete: "tel", required: true },
  { key: "nif", label: "NIF (opcional)" },
  { key: "company_name", label: "Empresa (opcional)", autoComplete: "organization" },
  { key: "address", label: "Morada", autoComplete: "street-address", required: true },
  { key: "postal_code", label: "Código postal", autoComplete: "postal-code", required: true },
  { key: "city", label: "Localidade", autoComplete: "address-level2", required: true },
  { key: "country", label: "País", autoComplete: "country-name", required: true },
];

const Conta = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const [form, setForm] = useState<ProfileForm>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth", { replace: true });
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    let active = true;
    supabase
      .from("profiles")
      .select("full_name, phone, nif, company_name, address, postal_code, city, country")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (!active) return;
        if (error) toast.error("Não foi possível carregar o seu perfil");
        setForm({
          full_name: data?.full_name ?? "",
          phone: data?.phone ?? "",
          nif: data?.nif ?? "",
          company_name: data?.company_name ?? "",
          address: data?.address ?? "",
          postal_code: data?.postal_code ?? "",
          city: data?.city ?? "",
          country: data?.country ?? "",
        });
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = profileSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("profiles").upsert({
      id: user.id,
      email: user.email,
      full_name: parsed.data.full_name,
      phone: parsed.data.phone,
      nif: parsed.data.nif ?? null,
      company_name: parsed.data.company_name ?? null,
      address: parsed.data.address,
      postal_code: parsed.data.postal_code,
      city: parsed.data.city,
      country: parsed.data.country,
    });
    setSaving(false);
    if (error) {
      toast.error("Não foi possível guardar as alterações");
      return;
    }
    toast.success("Dados guardados");
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/", { replace: true });
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />
      <section className="relative section-dark overflow-hidden pt-32 pb-20 md:pt-40 md:pb-24 min-h-screen">
        <GridPattern />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <SectionLabel index="[ 001 ]">Área de Cliente</SectionLabel>
                <h1 className="display-h1 text-3xl md:text-5xl mt-4">
                  A Minha <span className="lime-text">Conta</span>
                </h1>
                <p className="mt-4 text-muted-foreground">Sessão iniciada como {user?.email}</p>
              </div>
              <Button type="button" variant="outline" onClick={handleSignOut} className="uppercase tracking-wider font-heading min-h-[48px]">
                <LogOut className="mr-2 h-4 w-4" /> Terminar sessão
              </Button>
            </div>

            <Tabs defaultValue="encomendas" className="mt-10">
              <TabsList className="flex flex-wrap h-auto justify-start gap-1">
                <TabsTrigger value="encomendas" className="uppercase tracking-wider font-heading text-xs">Encomendas</TabsTrigger>
                <TabsTrigger value="historico" className="uppercase tracking-wider font-heading text-xs">Histórico</TabsTrigger>
                <TabsTrigger value="favoritos" className="uppercase tracking-wider font-heading text-xs">Favoritos</TabsTrigger>
                <TabsTrigger value="moradas" className="uppercase tracking-wider font-heading text-xs">Moradas</TabsTrigger>
                <TabsTrigger value="reunioes" className="uppercase tracking-wider font-heading text-xs">Reuniões</TabsTrigger>
                <TabsTrigger value="formacao" className="uppercase tracking-wider font-heading text-xs">Formação</TabsTrigger>
                <TabsTrigger value="orcamentos" className="uppercase tracking-wider font-heading text-xs">Orçamentos</TabsTrigger>
                <TabsTrigger value="dados" className="uppercase tracking-wider font-heading text-xs">Dados</TabsTrigger>
              </TabsList>

              <TabsContent value="encomendas" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Encomendas em curso</h2>
                <OrdersPanel />
              </TabsContent>

              <TabsContent value="historico" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Histórico de encomendas</h2>
                <OrdersPanel history />
              </TabsContent>

              <TabsContent value="favoritos" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Os meus favoritos</h2>
                <WishlistPanel />
              </TabsContent>

              <TabsContent value="moradas" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Moradas de entrega</h2>
                <AddressesPanel />
              </TabsContent>

              <TabsContent value="reunioes" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">As minhas reuniões</h2>
                <MeetingsPanel />
              </TabsContent>

              <TabsContent value="formacao" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">As minhas formações</h2>
                <TrainingsPanel />
              </TabsContent>

              <TabsContent value="orcamentos" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Os meus pedidos de orçamento</h2>
                <QuotesPanel />
              </TabsContent>

              <TabsContent value="dados" className="mt-8">
                <h2 className="font-heading uppercase tracking-wide text-lg mb-4">Dados pessoais e faturação</h2>
                <form onSubmit={handleSave} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {fields.map((f) => (
                    <div key={f.key} className="space-y-2">
                      <Label htmlFor={f.key}>{f.label}</Label>
                      <Input
                        id={f.key}
                        autoComplete={f.autoComplete}
                        required={f.required}
                        value={form[f.key] ?? ""}
                        onChange={(e) => setForm((prev) => ({ ...prev, [f.key]: e.target.value }))}
                      />
                    </div>
                  ))}
                  <div className="sm:col-span-2 mt-4">
                    <Button type="submit" disabled={saving} className="uppercase tracking-wider font-heading min-h-[48px]">
                      {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Guardar alterações
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default Conta;
