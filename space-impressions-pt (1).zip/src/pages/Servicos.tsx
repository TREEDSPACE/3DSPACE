import { motion } from "framer-motion";
import { Printer, PenTool, Layers, Upload, FileText, Settings, Truck, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandPattern from "@/components/BrandPattern";
import BrandArrow from "@/components/BrandArrow";
import TechLabel from "@/components/TechLabel";
import { Button } from "@/components/ui/button";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const copy = {
  pt: {
    catalogLabel: "// SERVIÇOS / CATÁLOGO",
    sectionLabel: "Serviços",
    titlePre: "Os Nossos ",
    titleLime: "Serviços",
    subtitle: "Soluções completas de impressão 3D para todos os seus projetos.",
    serviceRef: "// 0",
    serviceRefSuffix: " — SERVIÇO",
    services: [
      {
        icon: Printer,
        title: "Impressão 3D Personalizada",
        desc: "Imprimimos os seus modelos 3D com precisão e qualidade. Trabalhamos com diversos materiais como PLA, PETG, ABS, TPU e resinas, adaptando cada projeto às suas necessidades específicas.",
        features: ["Múltiplos materiais disponíveis", "Alta precisão dimensional", "Acabamento profissional", "Peças únicas ou em série"],
      },
      {
        icon: PenTool,
        title: "Modelação 3D",
        desc: "A nossa equipa de designers cria modelos 3D profissionais a partir do seu conceito, esboço ou ideia. Do papel ao digital, transformamos a sua visão num ficheiro pronto a imprimir.",
        features: ["Design a partir de esboço", "Otimização para impressão", "Revisões ilimitadas", "Ficheiros STL/OBJ incluídos"],
      },
      {
        icon: Layers,
        title: "Prototipagem Rápida",
        desc: "Acelere o desenvolvimento dos seus produtos com protótipos funcionais impressos em 3D. Ideal para testar conceitos, validar designs e apresentar a investidores.",
        features: ["Entrega rápida", "Protótipos funcionais", "Iteração rápida", "Múltiplas versões"],
      },
    ],
    processLabel: "Como Funciona",
    processTitlePre: "O Nosso ",
    processTitleLime: "Processo",
    processSteps: [
      { icon: Upload, title: "Upload", desc: "Envie o seu modelo 3D ou descreva a sua ideia." },
      { icon: FileText, title: "Orçamento", desc: "Receba um orçamento detalhado sem compromisso." },
      { icon: Settings, title: "Produção", desc: "Imprimimos o seu projeto com a máxima qualidade." },
      { icon: Truck, title: "Entrega", desc: "Receba o produto final na sua porta." },
    ],
    step: "Passo",
    requestQuote: "Pedir Orçamento",
  },
  en: {
    catalogLabel: "// SERVICES / CATALOGUE",
    sectionLabel: "Services",
    titlePre: "Our ",
    titleLime: "Services",
    subtitle: "Complete 3D printing solutions for all your projects.",
    serviceRef: "// 0",
    serviceRefSuffix: " — SERVICE",
    services: [
      {
        icon: Printer,
        title: "Custom 3D Printing",
        desc: "We print your 3D models with precision and quality. We work with a range of materials such as PLA, PETG, ABS, TPU and resins, tailoring every project to your specific needs.",
        features: ["Multiple materials available", "High dimensional accuracy", "Professional finish", "Single pieces or batches"],
      },
      {
        icon: PenTool,
        title: "3D Modelling",
        desc: "Our design team creates professional 3D models from your concept, sketch or idea. From paper to digital, we turn your vision into a print-ready file.",
        features: ["Design from sketch", "Print optimisation", "Unlimited revisions", "STL/OBJ files included"],
      },
      {
        icon: Layers,
        title: "Rapid Prototyping",
        desc: "Speed up your product development with functional 3D-printed prototypes. Ideal for testing concepts, validating designs and pitching to investors.",
        features: ["Fast turnaround", "Functional prototypes", "Rapid iteration", "Multiple versions"],
      },
    ],
    processLabel: "How It Works",
    processTitlePre: "Our ",
    processTitleLime: "Process",
    processSteps: [
      { icon: Upload, title: "Upload", desc: "Send us your 3D model or describe your idea." },
      { icon: FileText, title: "Quote", desc: "Receive a detailed, no-obligation quote." },
      { icon: Settings, title: "Production", desc: "We print your project to the highest quality." },
      { icon: Truck, title: "Delivery", desc: "Receive the final product at your door." },
    ],
    step: "Step",
    requestQuote: "Request a Quote",
  },
};

const Servicos = () => {
  const c = useCopy(copy);
  return (
  <div className="min-h-screen bg-background lg:pl-56">
    <Header />

    <section className="pt-24 pb-12 section-dark relative overflow-hidden">
      <GridPattern />
      <TechLabel className="!top-24">{c.catalogLabel}</TechLabel>
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
          <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.sectionLabel}</SectionLabel></motion.div>
          <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
            {c.titlePre}<span className="lime-text">{c.titleLime}</span>
          </motion.h1>
          <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
            {c.subtitle}
          </motion.p>
          <motion.div variants={fadeUp} className="mt-6"><BrandArrow size={40} /></motion.div>
        </motion.div>
      </div>
    </section>

    {/* Services - WHITE for contrast */}
    <section className="py-20 md:py-24 section-white relative overflow-hidden">
      <BrandPattern tone="dark" opacity={0.12} size={300/2} fade="top" />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="space-y-16 md:space-y-20">
          {c.services.map((s, i) => (
            <motion.div key={s.title} variants={fadeUp} className={`grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center`}>
              <div className={i % 2 === 1 ? "lg:order-2" : ""}>
                
                <s.icon className="w-10 h-10 md:w-12 md:h-12 text-black mt-3 mb-4" />
                <h2 className="display-h1 text-2xl md:text-4xl text-black">{s.title}</h2>
                <div className="w-12 h-px bg-[hsl(var(--brand-lime))] mt-4" />
                <p className="mt-4 text-black/60 leading-relaxed">{s.desc}</p>
                <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
                  <ul className="space-y-2">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-black/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))]" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link to="/contacto" className="inline-flex items-center gap-2 shrink-0 text-sm font-heading uppercase tracking-wider text-black border-b border-[hsl(var(--brand-lime))] pb-0.5 hover:text-[hsl(var(--brand-lime))] transition-colors">
                    {c.requestQuote} <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
              <div className={`relative bg-black rounded-lg h-48 md:h-64 lg:h-80 flex items-center justify-center overflow-hidden ${i % 2 === 1 ? "lg:order-1" : ""}`}>
                <GridPattern opacity={0.12} />
                <s.icon className="relative z-10 w-20 h-20 md:w-28 md:h-28 text-[hsl(var(--brand-lime))]/80" strokeWidth={1.2} />
                
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>

    {/* Process - DARK with grid */}
    <section className="py-20 md:py-24 section-dark relative overflow-hidden">
      <GridPattern />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
          <motion.div variants={fadeUp}><SectionLabel index="[ 002 ]">{c.processLabel}</SectionLabel></motion.div>
          <motion.h2 variants={fadeUp} className="display-h1 text-4xl md:text-6xl mt-4">
            {c.processTitlePre}<span className="lime-text">{c.processTitleLime}</span>
          </motion.h2>
        </motion.div>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {c.processSteps.map((step, i) => (
            <motion.div key={step.title} variants={fadeUp} className="text-center group">
              <div className="display-h1 text-5xl md:text-6xl text-foreground/15 group-hover:text-[hsl(var(--brand-lime))]/40 transition-colors mb-2">0{i + 1}</div>
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-full border-2 border-foreground/30 flex items-center justify-center mx-auto mb-4 group-hover:border-[hsl(var(--brand-lime))] transition-colors">
                <step.icon className="w-6 h-6 md:w-7 md:h-7 text-foreground group-hover:text-[hsl(var(--brand-lime))] transition-colors" />
              </div>
              <span className="text-xs font-mono text-[hsl(var(--brand-lime))] uppercase tracking-wider">{c.step} {i + 1}</span>
              <h3 className="font-heading font-semibold text-foreground uppercase mt-2 text-sm md:text-base">{step.title}</h3>
              <p className="text-muted-foreground text-xs md:text-sm mt-2">{step.desc}</p>
            </motion.div>
          ))}
        </motion.div>
        <div className="text-center mt-12 md:mt-16">
          <Button asChild size="lg" className="uppercase tracking-wider font-heading min-h-[48px]">
            <Link to="/contacto">{c.requestQuote} <ArrowRight className="ml-2" size={16} /></Link>
          </Button>
        </div>
      </div>
    </section>

    <Footer />
  </div>
  );
};

export default Servicos;
