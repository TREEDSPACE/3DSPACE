import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { GraduationCap, CheckCircle2, Loader2, BookOpen, Layers, Rocket } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import BrandPattern from "@/components/BrandPattern";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCopy, useI18n } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const today = new Date().toISOString().slice(0, 10);

const emptyForm = {
  name: "",
  email: "",
  phone: "",
  course_level: "",
  preferred_start_date: "",
  message: "",
};

const copy = {
  pt: {
    label001: "Formação",
    titleA: "Formação em ",
    titleB: "Impressão 3D",
    subtitle: "Cursos online com níveis progressivos. Aprenda a imprimir em 3D desde o zero ou aprofunde os seus conhecimentos técnicos com acompanhamento especializado.",
    levelsTitle: "Níveis de Formação",
    levels: [
      {
        key: "beginner",
        title: "Iniciado",
        icon: BookOpen,
        desc: "Introdução à impressão 3D: tipos de tecnologias, materiais, preparação de ficheiros e primeiras impressões.",
        topics: ["Fundamentos da impressão 3D", "Materiais: PLA, PETG, ABS", "Slicing básico (Cura/Bambu Studio)", "Resolução de problemas comuns"],
      },
      {
        key: "intermediate",
        title: "Intermédio",
        icon: Layers,
        desc: "Otimize os seus modelos, domine suportes, configurações avançadas e pós-processamento profissional.",
        topics: ["Otimização de modelos", "Suportes e orientação", "Pós-processamento", "Calibração avançada"],
      },
      {
        key: "advanced",
        title: "Avançado",
        icon: Rocket,
        desc: "Produção em série, prototipagem funcional, materiais técnicos e fluxos de trabalho empresariais.",
        topics: ["Materiais técnicos e compósitos", "Prototipagem funcional", "Produção em pequena série", "Fluxos B2B e orçamentação"],
      },
    ],
    formTitle: "Inscrição na Formação",
    requestSent: "Inscrição enviada",
    requestSentDesc: "Recebemos a sua inscrição. Entraremos em contacto em breve com os detalhes do curso e horários disponíveis.",
    registerAnother: "Inscrever outra pessoa",
    validation: {
      name: "Indique o seu nome",
      email: "Email inválido",
      courseLevel: "Selecione o nível de formação",
      message: "Descreva o seu objetivo com pelo menos 10 caracteres",
    },
    sendError: "Não foi possível enviar a inscrição. Tente novamente.",
    sendSuccess: "Inscrição enviada. Confirmamos por email.",
    name: "Nome",
    namePh: "O seu nome",
    email: "Email",
    emailPh: "o.seu@email.com",
    phone: "Telefone",
    phonePh: "+351 900 000 000",
    courseLevel: "Nível de formação",
    courseLevelPh: "Selecione o nível",
    preferredDate: "Data de início preferida",
    message: "Mensagem / Objetivo",
    messagePh: "O que pretende apender? Experiência prévia? Disponibilidade?",
    register: "Inscrever-me",
    accountNoteBefore: "Se já tem conta, as inscrições ficam visíveis na área de cliente, no separador",
    accountNoteBold: "Formação",
    accountNoteAfter: ".",
    formatLabel: "Formato",
    formatValue: "Online (em direto)",
  },
  en: {
    label001: "Training",
    titleA: "3D Printing ",
    titleB: "Training",
    subtitle: "Online courses with progressive levels. Learn 3D printing from scratch or deepen your technical knowledge with specialised support.",
    levelsTitle: "Training Levels",
    levels: [
      {
        key: "beginner",
        title: "Beginner",
        icon: BookOpen,
        desc: "Introduction to 3D printing: technologies, materials, file preparation and first prints.",
        topics: ["3D printing fundamentals", "Materials: PLA, PETG, ABS", "Basic slicing (Cura/Bambu Studio)", "Troubleshooting common issues"],
      },
      {
        key: "intermediate",
        title: "Intermediate",
        icon: Layers,
        desc: "Optimise your models, master supports, advanced settings and professional post-processing.",
        topics: ["Model optimisation", "Supports and orientation", "Post-processing", "Advanced calibration"],
      },
      {
        key: "advanced",
        title: "Advanced",
        icon: Rocket,
        desc: "Batch production, functional prototyping, technical materials and business workflows.",
        topics: ["Technical and composite materials", "Functional prototyping", "Small-batch production", "B2B workflows and quoting"],
      },
    ],
    formTitle: "Training Registration",
    requestSent: "Registration sent",
    requestSentDesc: "We received your registration. We'll contact you soon with course details and available schedules.",
    registerAnother: "Register someone else",
    validation: {
      name: "Please enter your name",
      email: "Invalid email",
      courseLevel: "Select a training level",
      message: "Describe your goal with at least 10 characters",
    },
    sendError: "Could not send the registration. Please try again.",
    sendSuccess: "Registration sent. We'll confirm by email.",
    name: "Name",
    namePh: "Your name",
    email: "Email",
    emailPh: "your@email.com",
    phone: "Phone",
    phonePh: "+351 900 000 000",
    courseLevel: "Training level",
    courseLevelPh: "Select the level",
    preferredDate: "Preferred start date",
    message: "Message / Goal",
    messagePh: "What do you want to learn? Previous experience? Availability?",
    register: "Register",
    accountNoteBefore: "If you already have an account, registrations are visible in your account area, under the",
    accountNoteBold: "Training",
    accountNoteAfter: "tab.",
    formatLabel: "Format",
    formatValue: "Online (live)",
  },
};

const Formacao = () => {
  const c = useCopy(copy);
  const { lang } = useI18n();
  const { user } = useAuth();
  const [form, setForm] = useState(emptyForm);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const registrationSchema = z.object({
    name: z.string().trim().min(1, { message: c.validation.name }).max(100),
    email: z.string().trim().email({ message: c.validation.email }).max(255),
    phone: z.string().trim().max(30).optional(),
    course_level: z.string().trim().min(1, { message: c.validation.courseLevel }).max(40),
    preferred_start_date: z.string().optional(),
    message: z.string().trim().min(10, { message: c.validation.message }).max(2000),
  });

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("full_name, phone")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        setForm((prev) => ({
          ...prev,
          name: prev.name || data?.full_name || "",
          email: prev.email || user.email || "",
          phone: prev.phone || data?.phone || "",
        }));
      });
  }, [user]);

  const set = (key: keyof typeof emptyForm, value: string) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = registrationSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (parsed.data.preferred_start_date && parsed.data.preferred_start_date < today) {
      toast.error(lang === "pt" ? "A data de início tem de ser futura" : "The start date must be in the future");
      return;
    }
    setSending(true);
    const { error } = await supabase.from("training_registrations" as any).insert({
      user_id: user?.id ?? null,
      name: parsed.data.name,
      email: parsed.data.email,
      phone: parsed.data.phone || null,
      course_level: parsed.data.course_level,
      format: "online",
      preferred_start_date: parsed.data.preferred_start_date || null,
      message: parsed.data.message,
      status: "pending",
    } as any);
    setSending(false);
    if (error) {
      toast.error(c.sendError);
      return;
    }
    toast.success(c.sendSuccess);
    setForm(emptyForm);
    setDone(true);
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      <section className="pt-24 pb-12 section-dark relative overflow-hidden">
        <BrandPattern tone="light" opacity={0.12} size={160} fade="radial" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
            <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.label001}</SectionLabel></motion.div>
            <motion.h1 variants={fadeUp} className="display-h1 text-4xl md:text-6xl mt-4">
              {c.titleA}<span className="lime-text">{c.titleB}</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
              {c.subtitle}
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Course levels - WHITE for contrast */}
      <section className="py-20 md:py-24 section-white relative overflow-hidden">
        <BrandPattern tone="dark" opacity={0.1} size={160} fade="top" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="mb-12 md:mb-16">
            <motion.h2 variants={fadeUp} className="display-h1 text-3xl md:text-5xl text-black">{c.levelsTitle}</motion.h2>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {c.levels.map((level) => (
              <motion.div key={level.key} variants={fadeUp} className="group relative bg-white border border-black/10 rounded-lg p-6 md:p-8 hover:border-[hsl(var(--brand-lime))]/60 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full border-2 border-black/10 flex items-center justify-center group-hover:border-[hsl(var(--brand-lime))] transition-colors">
                    <level.icon className="w-5 h-5 text-black group-hover:text-[hsl(var(--brand-lime))] transition-colors" />
                  </div>
                  <h3 className="font-heading font-semibold text-xl uppercase tracking-wide text-black">{level.title}</h3>
                </div>
                <p className="text-black/60 leading-relaxed mb-6">{level.desc}</p>
                <ul className="space-y-2">
                  {level.topics.map((topic) => (
                    <li key={topic} className="flex items-center gap-2 text-sm text-black/70">
                      <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))]" />
                      {topic}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Registration form - DARK */}
      <section className="py-20 md:py-24 section-dark relative overflow-hidden">
        <BrandPattern tone="light" opacity={0.1} size={160} fade="bottom" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-3 gap-12 md:gap-16">
            <motion.div variants={fadeUp} className="lg:col-span-2">
              <h2 className="text-xl md:text-2xl font-heading font-bold uppercase mb-8 text-foreground">{c.formTitle}</h2>

              {done ? (
                <div className="border border-foreground/10 bg-[hsl(var(--surface-elevated))] rounded-lg p-8 text-center">
                  <CheckCircle2 className="h-10 w-10 mx-auto text-[hsl(var(--brand-lime))]" />
                  <p className="mt-4 text-foreground font-heading uppercase tracking-wide">{c.requestSent}</p>
                  <p className="mt-2 text-muted-foreground text-sm">{c.requestSentDesc}</p>
                  <Button onClick={() => setDone(false)} className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
                    {c.registerAnother}
                  </Button>
                </div>
              ) : (
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="t-name" className="text-foreground">{c.name}</Label>
                      <Input id="t-name" required value={form.name} onChange={(e) => set("name", e.target.value)} placeholder={c.namePh} className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground placeholder:text-foreground/30" />
                    </div>
                    <div>
                      <Label htmlFor="t-email" className="text-foreground">{c.email}</Label>
                      <Input id="t-email" type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} placeholder={c.emailPh} className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground placeholder:text-foreground/30" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="t-phone" className="text-foreground">{c.phone}</Label>
                      <Input id="t-phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder={c.phonePh} className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground placeholder:text-foreground/30" />
                    </div>
                    <div>
                      <Label htmlFor="t-level" className="text-foreground">{c.courseLevel}</Label>
                      <Select value={form.course_level} onValueChange={(v) => set("course_level", v)}>
                        <SelectTrigger id="t-level" className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground">
                          <SelectValue placeholder={c.courseLevelPh} />
                        </SelectTrigger>
                        <SelectContent>
                          {c.levels.map((l) => (
                            <SelectItem key={l.key} value={l.key}>{l.title}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="t-date" className="text-foreground">{c.preferredDate}</Label>
                      <Input id="t-date" type="date" min={today} value={form.preferred_start_date} onChange={(e) => set("preferred_start_date", e.target.value)} className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground" />
                    </div>
                    <div>
                      <Label htmlFor="t-format" className="text-foreground">{c.formatLabel}</Label>
                      <Input id="t-format" value={c.formatValue} disabled className="mt-2 min-h-[48px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground/60 cursor-not-allowed" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="t-message" className="text-foreground">{c.message}</Label>
                    <Textarea id="t-message" required value={form.message} onChange={(e) => set("message", e.target.value)} placeholder={c.messagePh} className="mt-2 min-h-[150px] bg-[hsl(var(--surface-elevated))] border-foreground/15 text-foreground placeholder:text-foreground/30" />
                  </div>

                  <Button type="submit" size="lg" disabled={sending} className="uppercase tracking-wider font-heading min-h-[48px]">
                    {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <GraduationCap className="mr-2 h-4 w-4" />}
                    {c.register}
                  </Button>
                </form>
              )}
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-8">
              <div className="bg-[hsl(var(--surface-elevated))] border border-foreground/10 rounded-lg p-6 text-sm text-muted-foreground">
                {c.accountNoteBefore}{" "}<span className="text-foreground font-medium">{c.accountNoteBold}</span>{" "}{c.accountNoteAfter}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Formacao;
