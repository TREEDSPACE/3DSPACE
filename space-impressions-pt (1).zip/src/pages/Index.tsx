import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Printer, PenTool, Layers, Package, ArrowRight, CheckCircle, ShoppingCart, Loader2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandPattern from "@/components/BrandPattern";

import GeometricFrame from "@/components/GeometricFrame";
import ServiceFlipCard from "@/components/ServiceFlipCard";
import BrandArrow from "@/components/BrandArrow";
import { PortugueseFlag } from "@/components/PortugueseFlag";

import MonochromeImage from "@/components/MonochromeImage";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useFeaturedProducts, useSaleProducts } from "@/hooks/use-shopify-products";
import { formatPrice, getProductImage, getDiscountPercent } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { toast } from "sonner";
import aboutImg from "@/assets/about-workshop.jpg";
import businessImg from "@/assets/business-meeting.jpg";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const stagger = {
  visible: { transition: { staggerChildren: 0.15 } },
};

function CountUp({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          let current = 0;
          const step = Math.ceil(target / 40);
          const interval = setInterval(() => {
            current += step;
            if (current >= target) {
              setCount(target);
              clearInterval(interval);
            } else {
              setCount(current);
            }
          }, 30);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return (
    <div ref={ref} className="display-h1 text-5xl md:text-6xl text-foreground">
      {count}
      <span className="text-[hsl(var(--brand-lime))]">{suffix}</span>
    </div>
  );
}

const copy = {
  pt: {
    services: [
      { icon: Printer, title: "Impressão 3D Personalizada", desc: "Dê vida às suas ideias com impressão 3D de alta qualidade em diversos materiais." },
      { icon: PenTool, title: "Modelação 3D", desc: "Criamos modelos 3D profissionais a partir do seu conceito ou esboço." },
      { icon: Layers, title: "Prototipagem", desc: "Protótipos rápidos e funcionais para validar os seus projetos." },
      { icon: Package, title: "Produtos Personalizados", desc: "Artigos únicos e personalizados impressos em 3D para oferta ou uso pessoal." },
    ],
    stats: [
      { value: 500, suffix: "+", label: "Clientes Satisfeitos" },
      { value: 1200, suffix: "+", label: "Projetos Concluídos" },
      { value: 3, suffix: "+", label: "Anos de Experiência" },
      { value: 50, suffix: "+", label: "Materiais Disponíveis" },
    ],
    addedToCart: "Adicionado ao carrinho",
    heroBadge: "Impressão 3D em Portugal",
    heroTitle: "O futuro constrói-se no espaço certo!",
    heroSubtitle: "Fabricação aditiva de alta precisão para indústrias que exigem o impossível. Transformamos arquivos CAD em realidade física.",
    ctaQuote: "Solicite um Orçamento",
    ctaExplore: "Explorar Materiais",
    scrollHint: "Scroll para explorar",
    promoLabel: "Oportunidades",
    promoAll: "Ver Loja",
    promoEmpty: "Sem promoções ativas de momento.",
    servicesLabel: "// 02 — SERVIÇOS",
    sectionLabelServices: "Os Nossos Serviços",
    servicesTitlePre: "O Que ",
    servicesTitleLime: "Fazemos",
    productsLabel: "// 03 — PRODUTOS",
    sectionLabelProducts: "Produtos em Destaque",
    productsTitlePre: "Os Nossos ",
    productsTitleLime: "Produtos",
    productsSubtitle: "Descubra a nossa gama de produtos impressos em 3D, desde artigos decorativos a peças personalizadas.",
    noProducts: "Nenhum produto disponível de momento.",
    addToCart: "Adicionar",
    viewAllProducts: "Ver Todos os Produtos",
    aboutLabel: "Sobre Nós",
    aboutTitlePre: "Inovadores em ",
    aboutTitleLime: "Impressão 3D",
    aboutP1: "A 3D Space nasceu da paixão pela tecnologia e pela criatividade. Somos especialistas em transformar conceitos em objetos físicos através da impressão 3D, oferecendo soluções tanto para particulares como para empresas.",
    aboutP2: "Com equipamentos de última geração e uma equipa dedicada, garantimos qualidade e atenção ao detalhe em cada projeto.",
    aboutCta: "Saber Mais",
    aboutAlt: "Oficina 3D Space",
    statsLabel: "// 05 — NÚMEROS",
    b2bLabel: "// 06 — B2B",
    sectionLabelB2B: "Para Empresas",
    b2bTitlePre: "Soluções ",
    b2bTitleLime: "B2B",
    b2bTitlePost: " Personalizadas",
    b2bDesc: "Oferecemos soluções completas de impressão 3D para empresas de todos os setores. Desde prototipagem rápida a produção em série de peças personalizadas.",
    b2bItems: ["Prototipagem rápida e funcional", "Produção de peças em pequena série", "Soluções à medida para cada indústria", "Apoio técnico dedicado"],
    b2bCta: "Peça um Orçamento",
    b2bAlt: "Soluções empresariais",
  },
  en: {
    services: [
      { icon: Printer, title: "Custom 3D Printing", desc: "Bring your ideas to life with high-quality 3D printing in a range of materials." },
      { icon: PenTool, title: "3D Modelling", desc: "We create professional 3D models from your concept or sketch." },
      { icon: Layers, title: "Prototyping", desc: "Fast, functional prototypes to validate your projects." },
      { icon: Package, title: "Custom Products", desc: "Unique, personalised 3D-printed items for gifts or personal use." },
    ],
    stats: [
      { value: 500, suffix: "+", label: "Satisfied Clients" },
      { value: 1200, suffix: "+", label: "Completed Projects" },
      { value: 3, suffix: "+", label: "Years of Experience" },
      { value: 50, suffix: "+", label: "Materials Available" },
    ],
    addedToCart: "Added to cart",
    heroBadge: "3D Printing in Portugal",
    heroTitle: "The future is built in the right space!",
    heroSubtitle: "High-precision additive manufacturing for industries that demand the impossible. We turn CAD files into physical reality.",
    ctaQuote: "Request a Quote",
    ctaExplore: "Explore Materials",
    scrollHint: "Scroll to explore",
    promoLabel: "Opportunities",
    promoAll: "View Shop",
    promoEmpty: "No active promotions right now.",
    servicesLabel: "// 02 — SERVICES",
    sectionLabelServices: "Our Services",
    servicesTitlePre: "What We ",
    servicesTitleLime: "Do",
    productsLabel: "// 03 — PRODUCTS",
    sectionLabelProducts: "Featured Products",
    productsTitlePre: "Our ",
    productsTitleLime: "Products",
    productsSubtitle: "Discover our range of 3D-printed products, from decorative items to custom parts.",
    noProducts: "No products available at the moment.",
    addToCart: "Add to Cart",
    viewAllProducts: "View All Products",
    aboutLabel: "About Us",
    aboutTitlePre: "Innovators in ",
    aboutTitleLime: "3D Printing",
    aboutP1: "3D Space was born from a passion for technology and creativity. We specialise in turning concepts into physical objects through 3D printing, offering solutions for individuals and businesses alike.",
    aboutP2: "With state-of-the-art equipment and a dedicated team, we guarantee quality and attention to detail in every project.",
    aboutCta: "Learn More",
    aboutAlt: "3D Space workshop",
    statsLabel: "// 05 — NUMBERS",
    b2bLabel: "// 06 — B2B",
    sectionLabelB2B: "For Business",
    b2bTitlePre: "Tailored ",
    b2bTitleLime: "B2B",
    b2bTitlePost: " Solutions",
    b2bDesc: "We offer complete 3D printing solutions for businesses in every sector. From rapid prototyping to small-batch production of custom parts.",
    b2bItems: ["Fast, functional prototyping", "Small-batch part production", "Tailored solutions for every industry", "Dedicated technical support"],
    b2bCta: "Request a Quote",
    b2bAlt: "Business solutions",
  },
};

const Index = () => {
  const c = useCopy(copy);
  const { data: featuredProducts, isLoading: productsLoading } = useFeaturedProducts();
  const { data: saleProductsRaw, isLoading: saleLoading } = useSaleProducts(6);
  // fallback: se não houver promoções ativas, mostra destaques
  const promoItems = (saleProductsRaw ?? []).length > 0 ? saleProductsRaw ?? [] : featuredProducts ?? [];

  const { addItem, isLoading: cartLoading } = useCartStore();

  const handleAddToCart = async (p: NonNullable<typeof featuredProducts>[0]) => {
    const variant = p.node.variants.edges[0]?.node;
    if (!variant) return;
    await addItem({
      product: p,
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
    toast.success(c.addedToCart, { position: "top-center" });
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col overflow-hidden pt-20 sm:pt-24 lg:pt-[130px] pb-4 section-dark">
        {/* Top: headline + CTAs */}
        <div className="w-full px-4 md:px-6 lg:px-10 relative z-10">
          <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-3xl lg:max-w-none">
            <motion.div variants={fadeUp} className="inline-flex items-center gap-2 border border-foreground/20 rounded-md px-3 py-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))]" />
              <span className="tech-mono text-xs uppercase tracking-wider text-foreground">{c.heroBadge}</span>
              <PortugueseFlag className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </motion.div>

            <motion.h1 variants={fadeUp} className="display-h1 text-2xl sm:text-3xl md:text-[clamp(1.75rem,3.8vw,3.5rem)] lg:text-[clamp(1.5rem,3.2vw,2.5rem)] mt-3 text-foreground leading-[0.95] whitespace-normal lg:whitespace-nowrap">
              {c.heroTitle}
            </motion.h1>

            <motion.div variants={fadeUp} className="w-10 h-[3px] bg-[hsl(var(--brand-lime))] mt-3" />
          </motion.div>
        </div>

        {/* Oportunidades — painel de vidro unificado com CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="relative w-full mt-2 lg:mt-4 flex-1 min-h-0 flex flex-col"
        >
          {/* padrão de fundo */}
          <div className="absolute inset-0 pointer-events-none" aria-hidden>
            <BrandPattern opacity={0.12} size={160} fade="top" />
          </div>

          <div className="brand-opportunities relative flex-1 flex flex-col border-y border-foreground/12 overflow-hidden bg-gradient-to-b from-card/80 via-card/55 to-card/25 backdrop-blur-md">
            <BrandPattern opacity={0.18} size={160} fade="none" className="z-0" />
            {/* degradês suaves sobre o padrão */}
            <div className="absolute inset-0 z-[1] pointer-events-none bg-gradient-to-b from-background/70 via-transparent to-background/80" aria-hidden />
            <div className="absolute inset-0 z-[1] pointer-events-none bg-gradient-to-r from-background/60 via-transparent to-background/60" aria-hidden />

            {/* conteúdo das Oportunidades */}
            <div className="relative z-10 flex-1 min-h-0 flex flex-col px-4 md:px-6 lg:px-10 py-6 gap-6">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full rounded-full bg-[hsl(var(--brand-lime))] opacity-60 animate-ping" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[hsl(var(--brand-lime))]" />
                  </span>
                  <h2 className="font-heading uppercase tracking-[0.18em] text-xs md:text-sm text-foreground">
                    {c.promoLabel}
                  </h2>
                </div>
                <Link to="/produtos" className="group inline-flex items-center gap-1 tech-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-[hsl(var(--brand-lime))] transition-colors whitespace-nowrap">
                  {c.promoAll}
                  <ArrowRight size={12} className="transition-transform group-hover:translate-x-0.5" />
                </Link>
              </div>
              <div className="relative z-10 h-px w-full bg-gradient-to-r from-transparent via-foreground/20 to-transparent mt-2" />

              <div className="mt-2 flex-1 min-h-0 flex flex-col justify-center">
                {(saleLoading || productsLoading) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 sm:gap-6 lg:gap-8 w-full">
                    <Skeleton className="aspect-[3/4] w-full rounded-lg" />
                    <Skeleton className="aspect-[3/4] w-full rounded-lg hidden sm:block" />
                    <Skeleton className="aspect-[3/4] w-full rounded-lg hidden lg:block" />
                    <Skeleton className="aspect-[3/4] w-full rounded-lg hidden xl:block" />
                    <Skeleton className="aspect-[3/4] w-full rounded-lg hidden 2xl:block" />
                  </div>
                )}

                {!saleLoading && !productsLoading && promoItems.length === 0 && (
                  <p className="text-sm text-muted-foreground py-4">{c.promoEmpty}</p>
                )}

                {!saleLoading && !productsLoading && promoItems.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 sm:gap-6 lg:gap-8 w-full">
                    {promoItems.slice(0, 5).map((p, i) => (
                      <Link
                        key={p.node.id}
                        to={`/produto/${p.node.handle}`}
                        className={[
                          "group flex flex-col",
                          i === 1 ? "hidden sm:flex" : "",
                          i === 2 ? "hidden lg:flex" : "",
                          i === 3 ? "hidden xl:flex" : "",
                          i === 4 ? "hidden 2xl:flex" : "",
                        ].join(" ")}
                      >
                        <div className="relative aspect-[3/4] w-full overflow-hidden rounded-lg bg-secondary ring-1 ring-foreground/10">
                          <img
                            src={getProductImage(p)}
                            alt={p.node.title}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-[1.05] transition-transform duration-700"
                          />
                          {/* gradient veil */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
                          {getDiscountPercent(p) > 0 && (
                            <span className="absolute top-1.5 right-1.5 sm:top-2 sm:right-2 tech-mono text-[8px] sm:text-[10px] font-bold px-1.5 sm:px-2 py-0.5 sm:py-1 bg-[hsl(var(--brand-lime))] text-black rounded-md">
                              -{getDiscountPercent(p)}%
                            </span>
                          )}
                        </div>

                        <div className="mt-2 flex items-end justify-between gap-2 min-h-0">
                          <h3 className="font-heading uppercase tracking-wide text-[9px] sm:text-[11px] md:text-xs text-foreground line-clamp-1">
                            {p.node.title}
                          </h3>
                          <span className="font-heading text-[10px] sm:text-sm text-[hsl(var(--brand-lime))] whitespace-nowrap">
                            {formatPrice(p.node.priceRange.minVariantPrice.amount, p.node.priceRange.minVariantPrice.currencyCode)}
                          </span>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* CTAs — continuação do painel */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.55 }}
              className="relative z-10 border-t border-foreground/12 bg-foreground/[0.03] px-4 md:px-6 lg:px-10 py-3"
            >
              <div className="flex gap-3 flex-wrap items-center justify-start">
                <Button asChild size="default" className="uppercase tracking-wider font-heading min-h-[40px] px-5">
                  <Link to="/contacto">{c.ctaQuote} <ArrowRight className="ml-2" size={14} /></Link>
                </Button>
                <Button asChild variant="outline" size="default" className="uppercase tracking-wider font-heading min-h-[40px] px-5">
                  <Link to="/servicos">{c.ctaExplore}</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Services Section - WHITE for contrast */}
      <section className="py-20 md:py-24 section-white relative overflow-hidden">
        <BrandPattern tone="dark" opacity={0.12} size={300/2} fade="bottom" />
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.div variants={fadeUp}><SectionLabel index="[ 002 ]">{c.sectionLabelServices}</SectionLabel></motion.div>
            <motion.h2 variants={fadeUp} className="display-h1 text-4xl md:text-6xl mt-4">
              {c.servicesTitlePre}<span className="lime-text">{c.servicesTitleLime}</span>
            </motion.h2>
            <motion.div variants={fadeUp} className="flex justify-center mt-6">
              <BrandArrow size={36} />
            </motion.div>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {c.services.map((s) => (
              <motion.div key={s.title} variants={fadeUp}>
                <ServiceFlipCard icon={s.icon} title={s.title} desc={s.desc} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Featured Products - DARK with grid */}
      <section className="py-20 md:py-24 section-dark relative overflow-hidden">
        <BrandPattern opacity={0.10} size={360/2} fade="bottom" />

        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.div variants={fadeUp}><SectionLabel index="[ 003 ]">{c.sectionLabelProducts}</SectionLabel></motion.div>
            <motion.h2 variants={fadeUp} className="display-h1 text-4xl md:text-6xl mt-4">
              {c.productsTitlePre}<span className="lime-text">{c.productsTitleLime}</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="mt-4 text-muted-foreground max-w-lg mx-auto">
              {c.productsSubtitle}
            </motion.p>
          </motion.div>
          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i}>
                  <Skeleton className="aspect-square rounded-lg mb-4" />
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          ) : (featuredProducts ?? []).length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">{c.noProducts}</p>
            </div>
          ) : (
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {(featuredProducts ?? []).map((p) => (
                <motion.div key={p.node.id} variants={fadeUp} className="group">
                  <Link to={`/produto/${p.node.handle}`} className="block">
                    <div className="aspect-square overflow-hidden rounded-lg mb-4 bg-secondary">
                      <img src={getProductImage(p)} alt={p.node.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <h3 className="font-heading font-semibold text-foreground uppercase tracking-wide text-sm">{p.node.title}</h3>
                    <p className="text-muted-foreground text-sm font-medium mt-1">
                      {formatPrice(p.node.priceRange.minVariantPrice.amount, p.node.priceRange.minVariantPrice.currencyCode)}
                    </p>
                  </Link>
                  <Button
                    onClick={() => handleAddToCart(p)}
                    disabled={cartLoading}
                    size="sm"
                    className="mt-3 w-full uppercase tracking-wider text-xs font-heading min-h-[44px]"
                  >
                    {cartLoading ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <ShoppingCart className="w-3 h-3 mr-1" />}
                    {c.addToCart}
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          )}
          <div className="text-center mt-12">
            <Button asChild size="lg" variant="outline" className="uppercase tracking-wider font-heading min-h-[48px]">
              <Link to="/produtos">{c.viewAllProducts} <ArrowRight className="ml-2" size={16} /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section - DARK with geometric frame */}
      <section className="py-20 md:py-24 section-light relative overflow-hidden">
        <GridPattern className="opacity-50" />
        <BrandPattern opacity={0.09} size={420/2} fade="left" />

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-16 md:gap-20 items-center">
            <motion.div variants={fadeUp} className="px-4 md:px-8">
              <GeometricFrame label="3D_SPACE_HQ">
                <MonochromeImage src={aboutImg} alt={c.aboutAlt} className="w-full h-64 md:h-80 lg:h-[450px] object-cover" />
              </GeometricFrame>
            </motion.div>
            <motion.div variants={fadeUp}>
              <SectionLabel index="[ 004 ]">{c.aboutLabel}</SectionLabel>
              <h2 className="display-h1 text-3xl md:text-5xl mt-4">
                {c.aboutTitlePre}<span className="lime-text">{c.aboutTitleLime}</span>
              </h2>
              <p className="mt-6 text-muted-foreground leading-relaxed">
                {c.aboutP1}
              </p>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                {c.aboutP2}
              </p>
              <Button asChild size="lg" className="mt-8 uppercase tracking-wider font-heading min-h-[48px]">
                <Link to="/sobre">{c.aboutCta} <ArrowRight className="ml-2" size={16} /></Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section - WHITE for contrast */}
      <section className="py-20 md:py-24 section-white relative overflow-hidden">
        <BrandPattern tone="dark" opacity={0.10} size={260/2} fade="radial" />
        

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {c.stats.map((s, i) => (
              <motion.div key={s.label} variants={fadeUp} className={`relative ${i > 0 ? "md:border-l md:border-black/10" : ""}`}>
                <CountUp target={s.value} suffix={s.suffix} />
                <div className="w-8 h-px bg-[hsl(var(--brand-lime))] mx-auto my-3" />
                <p className="mt-2 text-sm uppercase tracking-wider text-black/60 font-heading">{s.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Para Empresas Section - DARK with grid + geometric frame */}
      <section className="py-20 md:py-24 section-dark relative overflow-hidden">
        <BrandPattern opacity={0.10} size={340/2} fade="right" />

        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
            <motion.div variants={fadeUp}>
              <SectionLabel index="[ 006 ]">{c.sectionLabelB2B}</SectionLabel>
              <h2 className="display-h1 text-3xl md:text-5xl mt-4">
                {c.b2bTitlePre}<span className="lime-text">{c.b2bTitleLime}</span>{c.b2bTitlePost}
              </h2>
              <p className="mt-6 text-muted-foreground leading-relaxed">
                {c.b2bDesc}
              </p>
              <div className="mt-6 space-y-3">
                {c.b2bItems.map((item) => (
                  <div key={item} className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-[hsl(var(--brand-lime))] flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8 flex items-center gap-4 flex-wrap">
                <Button asChild size="lg" className="uppercase tracking-wider font-heading min-h-[48px]">
                  <Link to="/contacto">{c.b2bCta} <ArrowRight className="ml-2" size={16} /></Link>
                </Button>
                <BrandArrow size={40} />
              </div>
            </motion.div>
            <motion.div variants={fadeUp} className="px-4 md:px-8">
              <GeometricFrame label="B2B_SOLUTIONS">
                <MonochromeImage src={businessImg} alt={c.b2bAlt} className="w-full h-64 md:h-80 lg:h-[450px] object-cover" />
              </GeometricFrame>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
