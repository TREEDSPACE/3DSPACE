import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Video, Clock, CheckCircle2, Loader2 } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const platformLabelsCopy = {
  pt: {
    meet: "Google Meet",
    zoom: "Zoom",
    teams: "Microsoft Teams",
  },
  en: {
    meet: "Google Meet",
    zoom: "Zoom",
    teams: "Microsoft Teams",
  },
};

export const platformLabels: Record<string, string> = platformLabelsCopy.pt;

const timeSlots = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"];

const today = new Date().toISOString().slice(0, 10);

const emptyForm = {
  name: "",
  email: "",
  phone: "",
  company_name: "",
  project_type: "",
  topic: "",
  description: "",
  platform: "meet",
  preferred_date: "",
  preferred_time: "",
  alternative_date: "",
  alternative_time: "",
};

const topicsCopy = {
  pt: {
    impressao: "Impressão 3D Personalizada",
    modelacao: "Modelação 3D",
    prototipagem: "Prototipagem Rápida",
    outro: "Outro",
  },
  en: {
    impressao: "Custom 3D Printing",
    modelacao: "3D Modelling",
    prototipagem: "Rapid Prototyping",
    outro: "Other",
  },
};

export const topics: Record<string, string> = topicsCopy.pt;

const copy = {
  pt: {
    projectTypes: {
      prototipagem: "Prototipagem / Engenharia",
      modelacao: "Modelação 3D",
      producao: "Produção em série",
      personalizado: "Projeto personalizado",
      empresa: "Parceria empresarial",
      outro: "Outro",
    },
    platformLabels: platformLabelsCopy.pt,
    validation: {
      name: "Indique o seu nome",
      email: "Email inválido",
      topic: "Selecione o tema",
      description: "Descreva o projeto com pelo menos 10 caracteres",
      preferredDate: "Escolha uma data preferida",
      preferredTime: "Escolha uma hora preferida",
    },
    dateMustBeFuture: "A data preferida tem de ser futura",
    sendError: "Não foi possível enviar o pedido de reunião. Tente novamente.",
    sendSuccess: "Pedido de reunião enviado. Confirmamos por email.",
    label001: "Videochamada",
    titleA: "Marcar",
    titleB: "Reunião",
    subtitle: "Para projetos mais detalhados, agende uma videochamada com a nossa equipa técnica. Analisamos consigo requisitos, materiais, prazos e custos.",
    formTitle: "Dados da Reunião",
    requestSent: "Pedido enviado",
    requestSentDesc: "Recebemos o seu pedido de videochamada. Enviamos a confirmação e o link da reunião por email.",
    bookAnother: "Marcar outra reunião",
    name: "Nome",
    namePh: "O seu nome",
    email: "Email",
    emailPh: "o.seu@email.com",
    phoneOpt: "Telefone (opcional)",
    phonePh: "+351 900 000 000",
    companyOpt: "Empresa (opcional)",
    companyPh: "Nome da empresa",
    projectType: "Tipo de projeto",
    projectTypePh: "Selecione o tipo",
    topic: "Tema",
    topicPh: "Selecione o tema",
    topics: topicsCopy.pt,
    platform: "Plataforma",
    platformPh: "Selecione a plataforma",
    preferredDate: "Data preferida",
    preferredTime: "Hora preferida",
    timePh: "Selecione a hora",
    altDate: "Data alternativa (opcional)",
    altTime: "Hora alternativa (opcional)",
    projectDesc: "Descrição do projeto",
    projectDescPh: "Objetivos, quantidades, materiais, prazos, ficheiros disponíveis...",
    requestCall: "Pedir Videochamada",
    howItWorks: "Como funciona",
    steps: [
      { n: "01.", text: "Envia o pedido com data e hora preferidas." },
      { n: "02.", text: "Confirmamos a disponibilidade por email." },
      { n: "03.", text: "Recebe o link da videochamada." },
      { n: "04.", text: "Reunião técnica de cerca de 30 minutos." },
    ],
    hours: "Seg-Sex: 9h-18h (hora de Lisboa)",
    accountNoteBefore: "Se já tem conta, os pedidos ficam visíveis na área de cliente, no separador",
    accountNoteBold: "Reuniões",
    accountNoteAfter: ".",
  },
  en: {
    projectTypes: {
      prototipagem: "Prototyping / Engineering",
      modelacao: "3D Modelling",
      producao: "Batch production",
      personalizado: "Custom project",
      empresa: "Business partnership",
      outro: "Other",
    },
    platformLabels: platformLabelsCopy.en,
    validation: {
      name: "Please enter your name",
      email: "Invalid email",
      topic: "Please select a topic",
      description: "Describe the project with at least 10 characters",
      preferredDate: "Choose a preferred date",
      preferredTime: "Choose a preferred time",
    },
    dateMustBeFuture: "The preferred date must be in the future",
    sendError: "Could not send the meeting request. Please try again.",
    sendSuccess: "Meeting request sent. We'll confirm by email.",
    label001: "Video Call",
    titleA: "Schedule",
    titleB: "Meeting",
    subtitle: "For more detailed projects, schedule a video call with our technical team. We'll go over requirements, materials, timelines and costs with you.",
    formTitle: "Meeting Details",
    requestSent: "Request sent",
    requestSentDesc: "We received your video call request. We'll send the confirmation and meeting link by email.",
    bookAnother: "Schedule another meeting",
    name: "Name",
    namePh: "Your name",
    email: "Email",
    emailPh: "your@email.com",
    phoneOpt: "Phone (optional)",
    phonePh: "+351 900 000 000",
    companyOpt: "Company (optional)",
    companyPh: "Company name",
    projectType: "Project type",
    projectTypePh: "Select the type",
    topic: "Topic",
    topicPh: "Select a topic",
    topics: topicsCopy.en,
    platform: "Platform",
    platformPh: "Select the platform",
    preferredDate: "Preferred date",
    preferredTime: "Preferred time",
    timePh: "Select a time",
    altDate: "Alternative date (optional)",
    altTime: "Alternative time (optional)",
    projectDesc: "Project description",
    projectDescPh: "Goals, quantities, materials, deadlines, available files...",
    requestCall: "Request Video Call",
    howItWorks: "How it works",
    steps: [
      { n: "01.", text: "Send the request with your preferred date and time." },
      { n: "02.", text: "We confirm availability by email." },
      { n: "03.", text: "You receive the video call link." },
      { n: "04.", text: "Technical meeting of about 30 minutes." },
    ],
    hours: "Mon-Fri: 9am-6pm (Lisbon time)",
    accountNoteBefore: "If you already have an account, requests are visible in your account area, under the",
    accountNoteBold: "Meetings",
    accountNoteAfter: "tab.",
  },
};

const Reuniao = () => {
  const c = useCopy(copy);
  const { user } = useAuth();
  const [form, setForm] = useState(emptyForm);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const meetingSchema = z.object({
    name: z.string().trim().min(1, { message: c.validation.name }).max(100),
    email: z.string().trim().email({ message: c.validation.email }).max(255),
    phone: z.string().trim().max(30).optional(),
    company_name: z.string().trim().max(120).optional(),
    project_type: z.string().trim().max(60).optional(),
    topic: z.string().trim().min(1, { message: c.validation.topic }).max(80),
    description: z.string().trim().min(10, { message: c.validation.description }).max(2000),
    platform: z.enum(["meet", "zoom", "teams"]),
    preferred_date: z.string().min(1, { message: c.validation.preferredDate }),
    preferred_time: z.string().min(1, { message: c.validation.preferredTime }),
    alternative_date: z.string().optional(),
    alternative_time: z.string().optional(),
  });

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("full_name, phone, company_name")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        setForm((prev) => ({
          ...prev,
          name: prev.name || data?.full_name || "",
          email: prev.email || user.email || "",
          phone: prev.phone || data?.phone || "",
          company_name: prev.company_name || data?.company_name || "",
        }));
      });
  }, [user]);

  const set = (key: keyof typeof emptyForm, value: string) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = meetingSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (parsed.data.preferred_date < today) {
      toast.error(c.dateMustBeFuture);
      return;
    }
    setSending(true);
    const { error } = await supabase.from("meeting_requests").insert({
      user_id: user?.id ?? null,
      name: parsed.data.name,
      email: parsed.data.email,
      phone: parsed.data.phone || null,
      company_name: parsed.data.company_name || null,
      project_type: parsed.data.project_type ? c.projectTypes[parsed.data.project_type as keyof typeof c.projectTypes] ?? parsed.data.project_type : null,
      topic: parsed.data.topic ? c.topics[parsed.data.topic as keyof typeof c.topics] ?? parsed.data.topic : null,
      description: parsed.data.description,
      platform: parsed.data.platform,
      preferred_date: parsed.data.preferred_date,
      preferred_time: parsed.data.preferred_time,
      alternative_date: parsed.data.alternative_date || null,
      alternative_time: parsed.data.alternative_time || null,
    });
    setSending(false);
    if (error) {
      toast.error(c.sendError);
      return;
    }
    toast.success(c.sendSuccess);
    setForm(emptyForm);
    setDone(true);
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      <section className="pt-24 pb-12 section-dark relative overflow-hidden">
        <GridPattern />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
            <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.label001}</SectionLabel></motion.div>
            <motion.h1 variants={fadeUp} className="display-h1 text-4xl md:text-6xl mt-4">
              {c.titleA} <span className="lime-text">{c.titleB}</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
              {c.subtitle}
            </motion.p>
          </motion.div>
        </div>
      </section>

      <section className="py-20 md:py-24 section-white">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-3 gap-12 md:gap-16">
            <motion.div variants={fadeUp} className="lg:col-span-2">
              <h2 className="text-xl md:text-2xl font-heading font-bold uppercase mb-8 text-black">{c.formTitle}</h2>

              {done ? (
                <div className="border border-black/10 bg-gray-50 rounded-lg p-8 text-center">
                  <CheckCircle2 className="h-10 w-10 mx-auto text-black" />
                  <p className="mt-4 text-black font-heading uppercase tracking-wide">{c.requestSent}</p>
                  <p className="mt-2 text-black/60 text-sm">
                    {c.requestSentDesc}
                  </p>
                  <Button onClick={() => setDone(false)} className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
                    {c.bookAnother}
                  </Button>
                </div>
              ) : (
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="m-name" className="text-black">{c.name}</Label>
                      <Input id="m-name" required value={form.name} onChange={(e) => set("name", e.target.value)} placeholder={c.namePh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                    </div>
                    <div>
                      <Label htmlFor="m-email" className="text-black">{c.email}</Label>
                      <Input id="m-email" type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} placeholder={c.emailPh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="m-phone" className="text-black">{c.phoneOpt}</Label>
                      <Input id="m-phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder={c.phonePh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                    </div>
                    <div>
                      <Label htmlFor="m-company" className="text-black">{c.companyOpt}</Label>
                      <Input id="m-company" value={form.company_name} onChange={(e) => set("company_name", e.target.value)} placeholder={c.companyPh} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="m-type" className="text-black">{c.projectType}</Label>
                      <Select value={form.project_type} onValueChange={(v) => set("project_type", v)}>
                        <SelectTrigger id="m-type" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                          <SelectValue placeholder={c.projectTypePh} />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(c.projectTypes).map(([v, l]) => (
                            <SelectItem key={v} value={v}>{l}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="m-platform" className="text-black">{c.platform}</Label>
                      <Select value={form.platform} onValueChange={(v) => set("platform", v)}>
                        <SelectTrigger id="m-platform" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                          <SelectValue placeholder={c.platformPh} />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(c.platformLabels).map(([v, l]) => (
                            <SelectItem key={v} value={v}>{l}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="m-topic" className="text-black">{c.topic}</Label>
                    <Select value={form.topic} onValueChange={(v) => set("topic", v)}>
                      <SelectTrigger id="m-topic" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                        <SelectValue placeholder={c.topicPh} />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(c.topics).map(([v, l]) => (
                          <SelectItem key={v} value={v}>{l}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="m-date" className="text-black">{c.preferredDate}</Label>
                      <Input id="m-date" type="date" required min={today} value={form.preferred_date} onChange={(e) => set("preferred_date", e.target.value)} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black" />
                    </div>
                    <div>
                      <Label htmlFor="m-time" className="text-black">{c.preferredTime}</Label>
                      <Select value={form.preferred_time} onValueChange={(v) => set("preferred_time", v)}>
                        <SelectTrigger id="m-time" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                          <SelectValue placeholder={c.timePh} />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map((t) => (
                            <SelectItem key={t} value={t}>{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="m-alt-date" className="text-black">{c.altDate}</Label>
                      <Input id="m-alt-date" type="date" min={today} value={form.alternative_date} onChange={(e) => set("alternative_date", e.target.value)} className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black" />
                    </div>
                    <div>
                      <Label htmlFor="m-alt-time" className="text-black">{c.altTime}</Label>
                      <Select value={form.alternative_time} onValueChange={(v) => set("alternative_time", v)}>
                        <SelectTrigger id="m-alt-time" className="mt-2 min-h-[48px] bg-gray-50 border-black/15 text-black">
                          <SelectValue placeholder={c.timePh} />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map((t) => (
                            <SelectItem key={t} value={t}>{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="m-desc" className="text-black">{c.projectDesc}</Label>
                    <Textarea id="m-desc" required value={form.description} onChange={(e) => set("description", e.target.value)} placeholder={c.projectDescPh} className="mt-2 min-h-[150px] bg-gray-50 border-black/15 text-black placeholder:text-black/30" />
                  </div>

                  <Button type="submit" size="lg" disabled={sending} className="uppercase tracking-wider font-heading min-h-[48px]">
                    {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Video className="mr-2 h-4 w-4" />}
                    {c.requestCall}
                  </Button>
                </form>
              )}
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-8">
              <div>
                <h3 className="font-heading font-semibold uppercase tracking-wide mb-4 text-black">{c.howItWorks}</h3>
                <ol className="space-y-4 text-sm text-black/60">
                  {c.steps.map((s) => (
                    <li key={s.n}><span className="text-black font-medium">{s.n}</span> {s.text}</li>
                  ))}
                </ol>
              </div>
              <div className="flex items-center gap-3 text-sm text-black/60">
                <Clock size={16} className="text-black" /> {c.hours}
              </div>
              <div className="bg-gray-100 rounded-lg p-6 text-sm text-black/60">
                {c.accountNoteBefore} <span className="text-black font-medium">{c.accountNoteBold}</span>{c.accountNoteAfter}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Reuniao;
