import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GridPattern from "@/components/GridPattern";
import SectionLabel from "@/components/SectionLabel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";

const emailSchema = z.string().trim().email({ message: "Email inválido" }).max(255);
const passwordSchema = z.string().min(8, { message: "A palavra-passe deve ter pelo menos 8 caracteres" }).max(72);

const requiredText = (max: number, label: string) =>
  z.string().trim().min(1, { message: `${label} é obrigatório` }).max(max, { message: `${label} demasiado longo` });

const signUpSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  full_name: z.string().trim().min(2, { message: "Indique o seu nome" }).max(100),
  phone: requiredText(30, "Telefone"),
  address: requiredText(200, "Morada"),
  postal_code: requiredText(20, "Código postal"),
  city: requiredText(100, "Localidade"),
  country: requiredText(100, "País"),
  nif: z.string().trim().max(20).optional(),
  company_name: z.string().trim().max(120, { message: "Nome da empresa demasiado longo" }).optional(),
});


const providers = [
  { id: "google" as const, label: "Google" },
  { id: "apple" as const, label: "Apple" },
  { id: "microsoft" as const, label: "Outlook / Microsoft" },
];

const Auth = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<string | null>(null);
  const [confirmSent, setConfirmSent] = useState(false);
  const [form, setForm] = useState({
    email: "",
    password: "",
    full_name: "",
    phone: "",
    address: "",
    postal_code: "",
    city: "",
    country: "",
    nif: "",
    company_name: "",
  });


  useEffect(() => {
    if (!authLoading && user) navigate("/conta", { replace: true });
  }, [user, authLoading, navigate]);

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSocial = async (provider: "google" | "apple" | "microsoft") => {
    setOauthLoading(provider);
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setOauthLoading(null);
      toast.error("Não foi possível iniciar sessão. Tente novamente.");
      return;
    }
    if (result.redirected) return;
    navigate("/conta", { replace: true });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "login") {
        const parsed = z.object({ email: emailSchema, password: z.string().min(1, { message: "Introduza a palavra-passe" }) }).safeParse(form);
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { error } = await supabase.auth.signInWithPassword({
          email: parsed.data.email,
          password: parsed.data.password,
        });
        if (error) {
          toast.error(error.message === "Invalid login credentials" ? "Credenciais inválidas" : error.message);
          return;
        }
        toast.success("Sessão iniciada");
        navigate("/conta", { replace: true });
      } else {
        const parsed = signUpSchema.safeParse(form);
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { data, error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: window.location.origin,
            data: {
              full_name: parsed.data.full_name,
              phone: parsed.data.phone,
              address: parsed.data.address,
              postal_code: parsed.data.postal_code,
              city: parsed.data.city,
              country: parsed.data.country,
              nif: parsed.data.nif ?? "",
              company_name: parsed.data.company_name ?? "",

            },
          },
        });
        if (error) {
          toast.error(error.message.includes("already registered") ? "Este email já está registado" : error.message);
          return;
        }
        if (!data.session) {
          setConfirmSent(true);
          return;
        }
        navigate("/conta", { replace: true });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    const parsed = emailSchema.safeParse(form.email);
    if (!parsed.success) {
      toast.error("Introduza o seu email para recuperar a palavra-passe");
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(parsed.data, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Enviámos um email para redefinir a palavra-passe");
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />
      <section className="relative section-dark overflow-hidden pt-32 pb-20 md:pt-40 md:pb-24 min-h-screen">
        <GridPattern />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-md mx-auto">
            <div className="text-center">
              <SectionLabel index="[ 001 ]">{mode === "login" ? "Iniciar Sessão" : "Criar Conta"}</SectionLabel>
              <h1 className="display-h1 text-3xl md:text-5xl mt-4">
                {mode === "login" ? <>A sua <span className="lime-text">Conta</span></> : <>Registe-se na <span className="lime-text">3D Space</span></>}
              </h1>
            </div>

            {confirmSent ? (
              <div className="mt-10 border border-border/40 rounded-lg p-6 text-center">
                <p className="text-muted-foreground">
                  Enviámos um email de confirmação para <span className="text-foreground">{form.email}</span>. Confirme a sua conta para iniciar sessão.
                </p>
                <Button variant="outline" className="mt-6 uppercase tracking-wider font-heading min-h-[48px]" onClick={() => { setConfirmSent(false); setMode("login"); }}>
                  Voltar ao início de sessão
                </Button>
              </div>
            ) : (
              <>
                <div className="mt-10 space-y-3">
                  {providers.map((p) => (
                    <Button
                      key={p.id}
                      type="button"
                      variant="outline"
                      onClick={() => handleSocial(p.id)}
                      disabled={!!oauthLoading}
                      className="w-full uppercase tracking-wider font-heading min-h-[48px]"
                    >
                      {oauthLoading === p.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Continuar com {p.label}
                    </Button>
                  ))}
                </div>

                <div className="flex items-center gap-4 my-8">
                  <div className="h-px flex-1 bg-border/40" />
                  <span className="tech-mono text-xs uppercase tracking-wider text-muted-foreground">ou</span>
                  <div className="h-px flex-1 bg-border/40" />
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {mode === "signup" && (
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Nome completo</Label>
                      <Input id="full_name" value={form.full_name} onChange={set("full_name")} autoComplete="name" required />
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={form.email} onChange={set("email")} autoComplete="email" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Palavra-passe</Label>
                    <Input
                      id="password"
                      type="password"
                      value={form.password}
                      onChange={set("password")}
                      autoComplete={mode === "login" ? "current-password" : "new-password"}
                      required
                    />
                  </div>

                  {mode === "signup" && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Telefone</Label>
                        <Input id="phone" value={form.phone} onChange={set("phone")} autoComplete="tel" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Morada</Label>
                        <Input id="address" value={form.address} onChange={set("address")} autoComplete="street-address" required />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="postal_code">Código postal</Label>
                          <Input id="postal_code" value={form.postal_code} onChange={set("postal_code")} autoComplete="postal-code" required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="city">Localidade</Label>
                          <Input id="city" value={form.city} onChange={set("city")} autoComplete="address-level2" required />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="country">País</Label>
                        <Input id="country" value={form.country} onChange={set("country")} autoComplete="country-name" required />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="nif">NIF <span className="text-muted-foreground">(opcional)</span></Label>
                        <Input id="nif" value={form.nif} onChange={set("nif")} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="company_name">Empresa <span className="text-muted-foreground">(opcional)</span></Label>
                        <Input id="company_name" value={form.company_name} onChange={set("company_name")} autoComplete="organization" />
                      </div>
                    </>
                  )}

                  <Button type="submit" disabled={loading} className="w-full uppercase tracking-wider font-heading min-h-[52px]">
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {mode === "login" ? "Entrar" : "Criar conta"}
                  </Button>
                </form>

                <div className="mt-6 text-center text-sm text-muted-foreground space-y-2">
                  {mode === "login" && (
                    <button type="button" onClick={handleReset} className="underline underline-offset-4 hover:text-foreground">
                      Esqueceu-se da palavra-passe?
                    </button>
                  )}
                  <p>
                    {mode === "login" ? "Ainda não tem conta?" : "Já tem conta?"}{" "}
                    <button
                      type="button"
                      onClick={() => setMode(mode === "login" ? "signup" : "login")}
                      className="text-[hsl(var(--brand-lime))] uppercase tracking-wider font-heading"
                    >
                      {mode === "login" ? "Registar" : "Iniciar sessão"}
                    </button>
                  </p>
                  <p>
                    <Link to="/" className="underline underline-offset-4 hover:text-foreground">Voltar ao início</Link>
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default Auth;
