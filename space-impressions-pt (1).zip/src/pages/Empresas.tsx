import { useId } from "react";
import { motion } from "framer-motion";
import { Building2, Factory, Stethoscope, GraduationCap, ShoppingBag, CheckCircle, ArrowRight, LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandPattern from "@/components/BrandPattern";
import GeometricFrame from "@/components/GeometricFrame";
import { Button } from "@/components/ui/button";
import businessImg from "@/assets/business-meeting.jpg";
import { useCopy } from "@/i18n";

const IndustryCard = ({ icon: Icon, title, desc }: { icon: LucideIcon; title: string; desc: string }) => {
  const gridId = useId();
  return (
    <div className="group h-[280px] md:h-[320px] rounded-lg bg-[hsl(0,0%,7%)] border border-white/10 overflow-hidden relative flex flex-col items-center justify-center p-5 md:p-6 text-center hover:border-[hsl(var(--brand-lime))]/60 transition-colors">
      <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id={`ind-grid-${gridId}`} width="30" height="30" patternUnits="userSpaceOnUse">
            <path d="M 30 0 L 0 0 0 30" fill="none" stroke="white" strokeWidth="0.5" opacity="0.08" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#ind-grid-${gridId})`} />
      </svg>
      <div className="relative z-10 flex flex-col items-center">
        <Icon className="w-10 h-10 md:w-12 md:h-12 text-white/70 group-hover:text-[hsl(var(--brand-lime))] transition-colors mb-4" />
        <h3 className="font-heading font-semibold text-sm md:text-base uppercase tracking-wide text-white mb-2">{title}</h3>
        <div className="w-8 h-px bg-[hsl(var(--brand-lime))] mb-3 opacity-0 group-hover:opacity-100 transition-opacity" />
        <p className="text-white/50 text-xs md:text-sm leading-relaxed">{desc}</p>
      </div>
    </div>
  );
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const copy = {
  pt: {
    label001: "Para Empresas",
    titleA: "Soluções",
    titleB: "Empresariais",
    subtitle: "Soluções de impressão 3D à medida para o seu negócio.",
    sectorsLabel: "Setores",
    industriesTitle: "Indústrias que Servimos",
    industries: [
      { icon: Building2, title: "Arquitetura", desc: "Maquetes e modelos arquitetónicos de alta precisão." },
      { icon: Factory, title: "Indústria", desc: "Peças funcionais, gabaritos e ferramentas de produção." },
      { icon: Stethoscope, title: "Saúde", desc: "Modelos anatómicos e dispositivos médicos personalizados." },
      { icon: GraduationCap, title: "Educação", desc: "Materiais didáticos e modelos para ensino." },
      { icon: ShoppingBag, title: "Retalho", desc: "Expositores, protótipos de embalagens e merchandising." },
    ],
    label003: "Porquê a 3D Space",
    partnerTitleA: "O Seu",
    partnerTitleB: "Parceiro",
    partnerTitleC: "em Impressão 3D",
    benefits: [
      "Consultoria técnica especializada",
      "Orçamentos personalizados",
      "Produção em pequena e média série",
      "Múltiplos materiais e acabamentos",
      "Entregas dentro dos prazos",
      "Apoio pós-venda dedicado",
    ],
    cta: "Peça um Orçamento",
    imgAlt: "Reunião empresarial",
  },
  en: {
    label001: "For Business",
    titleA: "Enterprise",
    titleB: "Solutions",
    subtitle: "Tailor-made 3D printing solutions for your business.",
    sectorsLabel: "Sectors",
    industriesTitle: "Industries We Serve",
    industries: [
      { icon: Building2, title: "Architecture", desc: "High-precision architectural models and mockups." },
      { icon: Factory, title: "Industry", desc: "Functional parts, jigs and production tooling." },
      { icon: Stethoscope, title: "Healthcare", desc: "Anatomical models and custom medical devices." },
      { icon: GraduationCap, title: "Education", desc: "Teaching materials and models for education." },
      { icon: ShoppingBag, title: "Retail", desc: "Displays, packaging prototypes and merchandising." },
    ],
    label003: "Why 3D Space",
    partnerTitleA: "Your",
    partnerTitleB: "Partner",
    partnerTitleC: "in 3D Printing",
    benefits: [
      "Specialised technical consulting",
      "Custom quotes",
      "Small and medium batch production",
      "Multiple materials and finishes",
      "On-time delivery",
      "Dedicated after-sales support",
    ],
    cta: "Request a Quote",
    imgAlt: "Business meeting",
  },
};

const Empresas = () => {
  const c = useCopy(copy);
  return (
  <div className="min-h-screen bg-background lg:pl-56">
    <Header />

    <section className="pt-24 pb-12 section-dark relative overflow-hidden">
      <GridPattern />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
          <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.label001}</SectionLabel></motion.div>
          <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
            {c.titleA} <span className="lime-text">{c.titleB}</span>
          </motion.h1>
          <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
            {c.subtitle}
          </motion.p>
        </motion.div>
      </div>
    </section>

    {/* Industries - WHITE */}
    <section className="py-20 md:py-24 section-white relative overflow-hidden">
      <BrandPattern tone="dark" opacity={0.12} size={280/2} fade="radial" />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
          <motion.div variants={fadeUp}><SectionLabel>{c.sectorsLabel}</SectionLabel></motion.div>
          <motion.h2 variants={fadeUp} className="text-2xl md:text-5xl font-heading font-bold uppercase mt-4">
            {c.industriesTitle}
          </motion.h2>
        </motion.div>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
          {c.industries.map((ind) => (
            <motion.div key={ind.title} variants={fadeUp}>
              <IndustryCard icon={ind.icon} title={ind.title} desc={ind.desc} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>

    {/* Benefits - DARK with grid + geometric frame */}
    <section className="py-20 md:py-24 section-dark relative overflow-hidden">
      <GridPattern />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <motion.div variants={fadeUp}>
            <SectionLabel index="[ 003 ]">{c.label003}</SectionLabel>
            <h2 className="display-h1 text-3xl md:text-5xl mt-4">
              {c.partnerTitleA} <span className="lime-text">{c.partnerTitleB}</span> {c.partnerTitleC}
            </h2>
            <div className="mt-8 space-y-3">
              {c.benefits.map((b) => (
                <div key={b} className="flex items-center gap-3 text-sm text-foreground/80">
                  <CheckCircle className="w-4 h-4 text-[hsl(var(--brand-lime))] flex-shrink-0" />
                  <span>{b}</span>
                </div>
              ))}
            </div>
            <Button asChild size="lg" className="mt-8 uppercase tracking-wider font-heading min-h-[48px]">
              <Link to="/contacto">{c.cta} <ArrowRight className="ml-2" size={16} /></Link>
            </Button>
          </motion.div>
          <motion.div variants={fadeUp} className="px-4 md:px-8">
            <GeometricFrame label="B2B_PARTNER">
              <img src={businessImg} alt={c.imgAlt} className="w-full h-64 md:h-80 lg:h-[400px] object-cover grayscale contrast-110" />
            </GeometricFrame>
          </motion.div>
        </motion.div>
      </div>
    </section>

    <Footer />
  </div>
  );
};

export default Empresas;
