import { motion } from "framer-motion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandArrow from "@/components/BrandArrow";
import TechLabel from "@/components/TechLabel";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const copy = {
  pt: {
    strap: "// LEGAL / PRIVACIDADE",
    label: "Privacidade",
    titlePre: "Política de ",
    titleLime: "Privacidade",
    subtitle: "A sua privacidade é importante para nós. Esta política descreve como recolhemos, usamos e protegemos os seus dados pessoais, em conformidade com o Regulamento Geral de Proteção de Dados (RGPD - UE 2016/679).",
    updated: "Última atualização: agosto de 2026",
    note: "Esta é uma versão temporária da política de privacidade, que será substituída por uma versão final em breve.",

    sec1Title: "1. Responsável pelo Tratamento de Dados",
    sec1Body: "O responsável pelo tratamento dos seus dados pessoais é a 3D Space, com sede em Lisboa, Portugal. Pode contactar-nos através do email geral.3dspace@gmail.com ou do telefone +351 931 060 445 para qualquer questão relacionada com a proteção dos seus dados.",

    sec2Title: "2. Dados Pessoais que Recolhemos",
    sec2Intro: "Recolhemos os seguintes dados pessoais, consoante a sua interação com o nosso site:",
    sec2Items: [
      "Dados de conta: nome completo, email, telefone, NIF, empresa, morada, código postal, cidade e país, recolhidos no registo e gestão de conta.",
      "Moradas de entrega: guardadas para processamento de encomendas.",
      "Pedidos de orçamento: nome, email, telefone, empresa, serviço pretendido e mensagem.",
      "Marcação de reuniões: nome, email, telefone, empresa, tipo de projeto, descrição, datas e horários preferidos, plataforma de videochamada e tema.",
      "Lista de desejos (wishlist): produtos que marca como favoritos.",
      "Dados de encomenda: processados através da Shopify, nossa plataforma de e-commerce.",
      "Dados de autenticação: quando inicia sessão através de Google, Apple, Microsoft (Outlook) ou Facebook (Meta), recebemos o nome e email associados a essa conta.",
    ],

    sec3Title: "3. Finalidades e Base Legal do Tratamento",
    sec3Items: [
      "Registo e gestão de conta de utilizador — consentimento e execução de contrato.",
      "Processamento de encomendas e entregas — execução de contrato.",
      "Resposta a pedidos de orçamento e informações — consentimento.",
      "Marcação e realização de videochamadas — consentimento.",
      "Gestão da lista de desejos — consentimento.",
      "Cumprimento de obrigações legais e fiscais — obrigação legal.",
    ],

    sec4Title: "4. Partilha de Dados com Terceiros",
    sec4Body: "Os seus dados pessoais são partilhados com os seguintes prestadores de serviços, que atuam como subcontratantes:",
    sec4Items: [
      "Shopify — processamento de pagamentos e gestão de encomendas.",
      "Google, Apple, Microsoft e Meta (Facebook) — autenticação OAuth, quando escolhe iniciar sessão através destes fornecedores.",
      "Fornecedores de email e videochamada (Google Meet, Zoom, Microsoft Teams) — realização das reuniões marcadas.",
    ],
    sec4Note: "Não vendemos nem comercializamos os seus dados pessoais com terceiros.",

    sec5Title: "5. Retenção de Dados",
    sec5Body: "Conservamos os seus dados pessoais apenas pelo tempo necessário para cumprir as finalidades descritas, ou conforme exigido por obrigação legal. Pode solicitar a eliminação da sua conta e dos respetivos dados a qualquer momento.",

    sec6Title: "6. Cookies e Armazenamento Local",
    sec6Body: "Utilizamos armazenamento local (localStorage) no seu navegador para guardar as suas preferências de idioma e de tema (claro/escuro), bem como a sua sessão de autenticação. Não utilizamos cookies de tracking publicitário de terceiros.",

    sec7Title: "7. Os Seus Direitos",
    sec7Intro: "Ao abrigo do RGPD, dispõe dos seguintes direitos sobre os seus dados pessoais:",
    sec7Items: [
      "Direito de acesso aos seus dados.",
      "Direito de retificação de dados incorretos.",
      "Direito ao apagamento (\"direito a ser esquecido\").",
      "Direito à limitação do tratamento.",
      "Direito à portabilidade dos dados.",
      "Direito de oposição ao tratamento.",
      "Direito de retirar o consentimento a qualquer momento.",
    ],
    sec7Body: "Para exercer qualquer um destes direitos, contacte-nos através de geral.3dspace@gmail.com. Caso considere que os seus direitos foram violados, pode apresentar reclamação junto da autoridade de controlo competente — a Comissão Nacional de Proteção de Dados (CNPD) em Portugal.",

    sec8Title: "8. Segurança dos Dados",
    sec8Body: "Implementamos medidas técnicas e organizativas adequadas para proteger os seus dados pessoais contra acesso não autorizado, perda ou utilização indevida, incluindo encriptação e controlo de acessos.",

    sec9Title: "9. Alterações a esta Política",
    sec9Body: "Reservamo-nos o direito de atualizar esta política de privacidade sempre que necessário. Recomendamos que consulte esta página regularmente para se manter informado sobre quaisquer alterações.",

    contactTitle: "Contactos",
    contactBody: "Para qualquer questão relacionada com a sua privacidade ou esta política, contacte-nos:",
  },
  en: {
    strap: "// LEGAL / PRIVACY",
    label: "Privacy",
    titlePre: "Privacy ",
    titleLime: "Policy",
    subtitle: "Your privacy matters to us. This policy describes how we collect, use and protect your personal data, in compliance with the General Data Protection Regulation (GDPR - EU 2016/679).",
    updated: "Last updated: August 2026",
    note: "This is a temporary version of the privacy policy, which will be replaced by a final version soon.",

    sec1Title: "1. Data Controller",
    sec1Body: "The controller of your personal data is 3D Space, based in Lisbon, Portugal. You can contact us at geral.3dspace@gmail.com or +351 931 060 445 regarding any matter related to the protection of your data.",

    sec2Title: "2. Personal Data We Collect",
    sec2Intro: "We collect the following personal data, depending on your interaction with our site:",
    sec2Items: [
      "Account data: full name, email, phone, tax ID (NIF), company, address, postal code, city and country, collected during registration and account management.",
      "Shipping addresses: stored for order processing.",
      "Quote requests: name, email, phone, company, requested service and message.",
      "Meeting bookings: name, email, phone, company, project type, description, preferred dates and times, video call platform and topic.",
      "Wishlist: products you mark as favourites.",
      "Order data: processed through Shopify, our e-commerce platform.",
      "Authentication data: when you sign in via Google, Apple, Microsoft (Outlook) or Facebook (Meta), we receive the name and email associated with that account.",
    ],

    sec3Title: "3. Purposes and Legal Basis of Processing",
    sec3Items: [
      "User account registration and management — consent and contract performance.",
      "Order processing and delivery — contract performance.",
      "Responding to quote requests and enquiries — consent.",
      "Booking and conducting video calls — consent.",
      "Wishlist management — consent.",
      "Fulfilment of legal and tax obligations — legal obligation.",
    ],

    sec4Title: "4. Sharing Data with Third Parties",
    sec4Body: "Your personal data is shared with the following service providers, acting as data processors:",
    sec4Items: [
      "Shopify — payment processing and order management.",
      "Google, Apple, Microsoft and Meta (Facebook) — OAuth authentication, when you choose to sign in via these providers.",
      "Email and video call providers (Google Meet, Zoom, Microsoft Teams) — conducting booked meetings.",
    ],
    sec4Note: "We do not sell or trade your personal data with third parties.",

    sec5Title: "5. Data Retention",
    sec5Body: "We retain your personal data only for as long as necessary to fulfil the purposes described, or as required by law. You can request the deletion of your account and associated data at any time.",

    sec6Title: "6. Cookies and Local Storage",
    sec6Body: "We use local storage (localStorage) in your browser to store your language and theme (light/dark) preferences, as well as your authentication session. We do not use third-party advertising tracking cookies.",

    sec7Title: "7. Your Rights",
    sec7Intro: "Under the GDPR, you have the following rights regarding your personal data:",
    sec7Items: [
      "Right of access to your data.",
      "Right to rectify incorrect data.",
      "Right to erasure (\"right to be forgotten\").",
      "Right to restrict processing.",
      "Right to data portability.",
      "Right to object to processing.",
      "Right to withdraw consent at any time.",
    ],
    sec7Body: "To exercise any of these rights, contact us at geral.3dspace@gmail.com. If you believe your rights have been violated, you may lodge a complaint with the competent supervisory authority — the Portuguese Data Protection Authority (CNPD).",

    sec8Title: "8. Data Security",
    sec8Body: "We implement appropriate technical and organisational measures to protect your personal data against unauthorised access, loss or misuse, including encryption and access controls.",

    sec9Title: "9. Changes to this Policy",
    sec9Body: "We reserve the right to update this privacy policy whenever necessary. We recommend that you check this page regularly to stay informed of any changes.",

    contactTitle: "Contacts",
    contactBody: "For any question regarding your privacy or this policy, contact us:",
  },
};

const Privacidade = () => {
  const c = useCopy(copy);
  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      <section className="pt-24 pb-12 section-dark relative overflow-hidden">
        <GridPattern />
        <TechLabel className="!top-24">{c.strap}</TechLabel>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-3xl">
            <motion.div variants={fadeUp}><SectionLabel>{c.label}</SectionLabel></motion.div>
            <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
              {c.titlePre}<span className="lime-text">{c.titleLime}</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg leading-relaxed">
              {c.subtitle}
            </motion.p>
            <motion.div variants={fadeUp} className="mt-6 flex items-center gap-4">
              <BrandArrow size={40} />
              <span className="tech-mono text-foreground/50 text-sm">{c.updated}</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 md:py-24 section-white">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-3xl mx-auto space-y-10">
            <motion.div variants={fadeUp} className="border-l-2 border-[hsl(var(--brand-lime))] pl-4 py-2 bg-[hsl(var(--brand-lime))]/5 rounded-r">
              <p className="text-sm text-black/70">{c.note}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-2">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec1Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec1Body}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-3">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec2Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec2Intro}</p>
              <ul className="space-y-2">
                {c.sec2Items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-black/70">
                    <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))] mt-2 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-3">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec3Title}</h2>
              <ul className="space-y-2">
                {c.sec3Items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-black/70">
                    <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))] mt-2 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-3">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec4Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec4Body}</p>
              <ul className="space-y-2">
                {c.sec4Items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-black/70">
                    <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))] mt-2 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm text-black/70 italic">{c.sec4Note}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-2">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec5Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec5Body}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-2">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec6Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec6Body}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-3">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec7Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec7Intro}</p>
              <ul className="space-y-2">
                {c.sec7Items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-black/70">
                    <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))] mt-2 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-black/70 leading-relaxed">{c.sec7Body}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-2">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec8Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec8Body}</p>
            </motion.div>

            <motion.div variants={fadeUp} className="space-y-2">
              <h2 className="font-heading text-xl md:text-2xl text-black uppercase tracking-wide">{c.sec9Title}</h2>
              <p className="text-black/70 leading-relaxed">{c.sec9Body}</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 md:py-20 section-dark relative overflow-hidden">
        <GridPattern />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-2xl md:text-3xl text-foreground uppercase tracking-wide mb-4">{c.contactTitle}</h2>
            <p className="text-muted-foreground mb-6">{c.contactBody}</p>
            <div className="flex flex-col gap-2 items-center text-foreground/80">
              <a href="mailto:geral.3dspace@gmail.com" className="hover:text-[hsl(var(--brand-lime))] transition-colors">geral.3dspace@gmail.com</a>
              <a href="tel:+351931060445" className="hover:text-[hsl(var(--brand-lime))] transition-colors">+351 931 060 445</a>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Privacidade;
