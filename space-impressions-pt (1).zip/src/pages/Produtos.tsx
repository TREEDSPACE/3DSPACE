import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ShoppingCart, Loader2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import { Button } from "@/components/ui/button";
import WishlistButton from "@/components/WishlistButton";
import { Skeleton } from "@/components/ui/skeleton";
import { useShopifyProducts } from "@/hooks/use-shopify-products";
import { formatPrice, getProductImage, getProductCategories } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { toast } from "sonner";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

const copy = {
  pt: {
    all: "Todos",
    label001: "Loja",
    titleA: "Os Nossos",
    titleB: "Produtos",
    subtitle: "Explore a nossa coleção de produtos impressos em 3D.",
    addedToCart: "Adicionado ao carrinho",
    errorLoad: "Não foi possível carregar os produtos. Tente novamente mais tarde.",
    add: "Adicionar",
    noProducts: "Nenhum produto encontrado.",
  },
  en: {
    all: "All",
    label001: "Shop",
    titleA: "Our",
    titleB: "Products",
    subtitle: "Explore our collection of 3D printed products.",
    addedToCart: "Added to cart",
    errorLoad: "Could not load products. Please try again later.",
    add: "Add",
    noProducts: "No products found.",
  },
};

const Produtos = () => {
  const c = useCopy(copy);
  const [active, setActive] = useState(c.all);
  const { data: products, isLoading, error } = useShopifyProducts();
  const { addItem, isLoading: cartLoading } = useCartStore();

  const categories = products ? getProductCategories(products) : [c.all];
  const filtered =
    active === c.all
      ? products ?? []
      : (products ?? []).filter((p) => p.node.productType === active);

  const handleAddToCart = async (p: typeof filtered[0]) => {
    const variant = p.node.variants.edges[0]?.node;
    if (!variant) return;
    await addItem({
      product: p,
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
    toast.success(c.addedToCart, { position: "top-center" });
  };

  return (
    <div className="min-h-screen bg-background lg:pl-56">
      <Header />

      <section className="pt-24 pb-12 section-dark relative overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
            <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.label001}</SectionLabel></motion.div>
            <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
              {c.titleA} <span className="lime-text">{c.titleB}</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="mt-4 text-muted-foreground text-base md:text-lg">
              {c.subtitle}
            </motion.p>
          </motion.div>
        </div>
      </section>

      <section className="py-20 md:py-24 section-dark">
        <div className="container mx-auto px-4 md:px-6">
          {/* Filters - horizontal scroll on mobile */}
          <div className="flex gap-3 mb-12 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0 md:flex-wrap scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActive(cat)}
                className={`px-5 py-2.5 text-sm font-heading uppercase tracking-wider rounded-full border transition-colors whitespace-nowrap min-h-[44px] ${
                  active === cat
                    ? "bg-[hsl(var(--brand-lime))] text-black border-[hsl(var(--brand-lime))]"
                    : "border-border text-muted-foreground hover:border-[hsl(var(--brand-lime))]/50 hover:text-[hsl(var(--brand-lime))]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {isLoading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i}>
                  <Skeleton className="aspect-square rounded-lg mb-4" />
                  <Skeleton className="h-3 w-20 mb-2" />
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          )}

          {error && (
            <div className="text-center py-16">
              <p className="text-muted-foreground">{c.errorLoad}</p>
            </div>
          )}

          {!isLoading && !error && filtered.length > 0 && (
            <motion.div initial="hidden" animate="visible" variants={stagger} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {filtered.map((p, i) => (
                <motion.div key={`${p.node.id}-${i}`} variants={fadeUp} className="group">
                  <div className="relative">
                    <WishlistButton
                      className="absolute top-3 right-3 z-10"
                      product={{
                        product_handle: p.node.handle,
                        product_id: p.node.id,
                        title: p.node.title,
                        image_url: getProductImage(p),
                        price: parseFloat(p.node.priceRange.minVariantPrice.amount),
                        currency: p.node.priceRange.minVariantPrice.currencyCode,
                      }}
                    />
                    <Link to={`/produto/${p.node.handle}`} className="block">
                      <div className="aspect-square overflow-hidden rounded-lg bg-secondary mb-4">
                        <img src={getProductImage(p)} alt={p.node.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      </div>
                    </Link>
                  </div>
                  <Link to={`/produto/${p.node.handle}`} className="block">

                    <span className="text-xs uppercase tracking-wider text-muted-foreground">{p.node.productType}</span>
                    <h3 className="font-heading font-semibold uppercase tracking-wide text-sm mt-1">{p.node.title}</h3>
                    <p className="text-muted-foreground font-medium text-sm mt-1">
                      {formatPrice(p.node.priceRange.minVariantPrice.amount, p.node.priceRange.minVariantPrice.currencyCode)}
                    </p>
                  </Link>
                  <Button
                    onClick={() => handleAddToCart(p)}
                    disabled={cartLoading}
                    size="sm"
                    className="mt-3 w-full uppercase tracking-wider text-xs font-heading min-h-[44px]"
                  >
                    {cartLoading ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <ShoppingCart className="w-3 h-3 mr-1" />}
                    {c.add}
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          )}

          {!isLoading && !error && filtered.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground">{c.noProducts}</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Produtos;
