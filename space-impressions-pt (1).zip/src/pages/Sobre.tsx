import { motion } from "framer-motion";
import { Target, Heart, Zap, Users } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionLabel from "@/components/SectionLabel";
import GridPattern from "@/components/GridPattern";
import BrandPattern from "@/components/BrandPattern";
import GeometricFrame from "@/components/GeometricFrame";
import BrandArrow from "@/components/BrandArrow";
import TechLabel from "@/components/TechLabel";
import MonochromeImage from "@/components/MonochromeImage";
import aboutImg from "@/assets/about-workshop.jpg";
import product1 from "@/assets/product-1.jpg";
import product2 from "@/assets/product-2.jpg";
import product3 from "@/assets/product-3.jpg";
import product4 from "@/assets/product-4.jpg";
import { useCopy } from "@/i18n";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};
const stagger = { visible: { transition: { staggerChildren: 0.15 } } };

const copy = {
  pt: {
    aboutSection: "// SOBRE / 3D.SPACE",
    sectionLabel: "Sobre Nós",
    titlePre: "A Nossa ",
    titleLime: "História",
    workshopLabel: "WORKSHOP_01",
    aboutAlt: "Oficina 3D Space",
    heading: <>A 3D <span className="lime-text">Space</span></>,
    p1: "A 3D Space nasceu em Portugal com uma missão clara: democratizar o acesso à impressão 3D de alta qualidade. Acreditamos que todos devem poder transformar as suas ideias em objetos reais.",
    p2: "Desde o início, investimos em equipamentos de última geração e numa equipa apaixonada por tecnologia. Hoje, servimos centenas de clientes particulares e empresas, oferecendo desde produtos personalizados a soluções industriais.",
    p3: "A nossa dedicação à qualidade, inovação e satisfação do cliente é o que nos distingue no mercado português.",
    valuesLabel: "Os Nossos Valores",
    valuesTitle: "O Que Nos Move",
    values: [
      { icon: Target, title: "Qualidade", desc: "Compromisso com a excelência em cada peça que produzimos." },
      { icon: Heart, title: "Paixão", desc: "Apaixonados pela tecnologia e pela criatividade." },
      { icon: Zap, title: "Inovação", desc: "Sempre na vanguarda das últimas tecnologias de impressão 3D." },
      { icon: Users, title: "Cliente", desc: "O cliente está no centro de tudo o que fazemos." },
    ],
    galleryLabel: "Galeria",
    galleryTitle: "Os Nossos Trabalhos",
    workAlt: "Trabalho",
  },
  en: {
    aboutSection: "// ABOUT / 3D.SPACE",
    sectionLabel: "About Us",
    titlePre: "Our ",
    titleLime: "Story",
    workshopLabel: "WORKSHOP_01",
    aboutAlt: "3D Space workshop",
    heading: <>3D <span className="lime-text">Space</span></>,
    p1: "3D Space was born in Portugal with a clear mission: to democratise access to high-quality 3D printing. We believe everyone should be able to turn their ideas into real objects.",
    p2: "From the start, we invested in state-of-the-art equipment and a team passionate about technology. Today, we serve hundreds of individual customers and businesses, offering everything from custom products to industrial solutions.",
    p3: "Our dedication to quality, innovation and customer satisfaction is what sets us apart in the Portuguese market.",
    valuesLabel: "Our Values",
    valuesTitle: "What Drives Us",
    values: [
      { icon: Target, title: "Quality", desc: "A commitment to excellence in every piece we produce." },
      { icon: Heart, title: "Passion", desc: "Passionate about technology and creativity." },
      { icon: Zap, title: "Innovation", desc: "Always at the forefront of the latest 3D printing technologies." },
      { icon: Users, title: "Customer", desc: "The customer is at the heart of everything we do." },
    ],
    galleryLabel: "Gallery",
    galleryTitle: "Our Work",
    workAlt: "Work",
  },
};

const Sobre = () => {
  const c = useCopy(copy);
  return (
  <div className="min-h-screen bg-background lg:pl-56">
    <Header />

    <section className="pt-24 pb-12 section-dark relative overflow-hidden">
      <GridPattern />
      <TechLabel className="!top-24">{c.aboutSection}</TechLabel>
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
          <motion.div variants={fadeUp}><SectionLabel index="[ 001 ]">{c.sectionLabel}</SectionLabel></motion.div>
          <motion.h1 variants={fadeUp} className="display-h1 text-5xl md:text-7xl mt-4">
            {c.titlePre}<span className="lime-text">{c.titleLime}</span>
          </motion.h1>
          <motion.div variants={fadeUp} className="mt-6"><BrandArrow size={40} /></motion.div>
        </motion.div>
      </div>
    </section>

    {/* Story - WHITE */}
    <section className="py-20 md:py-24 section-white relative overflow-hidden">
      <BrandPattern tone="dark" opacity={0.11} size={320/2} fade="right" />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <motion.div variants={fadeUp} className="px-4 md:px-8">
            <GeometricFrame label={c.workshopLabel}>
              <MonochromeImage src={aboutImg} alt={c.aboutAlt} className="w-full h-64 md:h-80 lg:h-[450px] object-cover" />
            </GeometricFrame>
          </motion.div>
          <motion.div variants={fadeUp}>
            <h2 className="display-h1 text-3xl md:text-5xl text-black">{c.heading}</h2>
            <p className="mt-6 text-black/50 leading-relaxed">
              {c.p1}
            </p>
            <p className="mt-4 text-black/50 leading-relaxed">
              {c.p2}
            </p>
            <p className="mt-4 text-black/50 leading-relaxed">
              {c.p3}
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>

    {/* Values - DARK with grid */}
    <section className="py-20 md:py-24 section-dark relative overflow-hidden">
      <GridPattern />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
          <motion.div variants={fadeUp}><SectionLabel>{c.valuesLabel}</SectionLabel></motion.div>
          <motion.h2 variants={fadeUp} className="text-2xl md:text-5xl font-heading font-bold uppercase mt-4">
            {c.valuesTitle}
          </motion.h2>
        </motion.div>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
        {c.values.map((v) => (
          <motion.div key={v.title} variants={fadeUp} className="text-center p-4 md:p-8 group">
            <div className="w-14 h-14 md:w-16 md:h-16 rounded-full border-2 border-foreground/30 flex items-center justify-center mx-auto mb-4 group-hover:border-[hsl(var(--brand-lime))] transition-colors">
              <v.icon className="w-6 h-6 md:w-7 md:h-7 text-foreground group-hover:text-[hsl(var(--brand-lime))] transition-colors" />
            </div>
            <h3 className="font-heading font-semibold text-foreground uppercase tracking-wide text-sm md:text-base">{v.title}</h3>
            <p className="text-muted-foreground text-xs md:text-sm mt-2">{v.desc}</p>
          </motion.div>
        ))}
        </motion.div>
      </div>
    </section>

    {/* Gallery - LIGHT */}
    <section className="py-20 md:py-24 section-light relative overflow-hidden">
      <GridPattern className="opacity-50" />
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
          <motion.div variants={fadeUp}><SectionLabel>{c.galleryLabel}</SectionLabel></motion.div>
          <motion.h2 variants={fadeUp} className="text-2xl md:text-5xl font-heading font-bold uppercase mt-4">
            {c.galleryTitle}
          </motion.h2>
        </motion.div>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {[product1, product2, product3, product4].map((img, i) => (
            <motion.div key={i} variants={fadeUp} className="aspect-square overflow-hidden rounded-lg">
              <img src={img} alt={`${c.workAlt} ${i + 1}`} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>

    <Footer />
  </div>
  );
};

export default Sobre;
