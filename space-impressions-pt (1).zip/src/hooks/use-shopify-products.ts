import { useQuery } from "@tanstack/react-query";
import { fetchAllProducts, fetchFeaturedProducts, fetchProductByHandle, fetchSaleProducts, type ShopifyProduct } from "@/lib/shopify";

export function useShopifyProducts() {
  return useQuery<ShopifyProduct[]>({
    queryKey: ["shopify-products"],
    queryFn: () => fetchAllProducts(),
    staleTime: 1000 * 60 * 5,
  });
}

export function useFeaturedProducts() {
  return useQuery<ShopifyProduct[]>({
    queryKey: ["shopify-featured-products"],
    queryFn: () => fetchFeaturedProducts(4),
    staleTime: 1000 * 60 * 5,
  });
}

export function useProductByHandle(handle: string) {
  return useQuery({
    queryKey: ["shopify-product", handle],
    queryFn: () => fetchProductByHandle(handle),
    staleTime: 1000 * 60 * 5,
    enabled: !!handle,
  });
}

export function useSaleProducts(limit = 3) {
  return useQuery<ShopifyProduct[]>({
    queryKey: ["shopify-sale-products", limit],
    queryFn: () => fetchSaleProducts(limit),
    staleTime: 1000 * 60 * 5,
  });
}
