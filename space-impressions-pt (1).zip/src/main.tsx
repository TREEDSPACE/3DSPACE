import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

const fonts = document.createElement("link");
fonts.rel = "stylesheet";
fonts.href = "https://fonts.googleapis.com/css2?family=Rubik+One&family=Rajdhani:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&family=Exo+2:wght@300;400;500;600;700&display=swap";
document.head.appendChild(fonts);

const root = document.getElementById("root");
if (root) createRoot(root).render(<App />);
