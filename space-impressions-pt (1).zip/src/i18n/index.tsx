import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type Lang = "pt" | "en";

interface I18nContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  toggleLang: () => void;
}

const I18nContext = createContext<I18nContextValue>({
  lang: "pt",
  setLang: () => {},
  toggleLang: () => {},
});

const STORAGE_KEY = "3dspace-lang";

const getInitialLang = (): Lang => {
  if (typeof window === "undefined") return "pt";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "pt" || stored === "en") return stored;
  return navigator.language?.toLowerCase().startsWith("en") ? "en" : "pt";
};

export const I18nProvider = ({ children }: { children: ReactNode }) => {
  const [lang, setLangState] = useState<Lang>(getInitialLang);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, lang);
    document.documentElement.lang = lang === "pt" ? "pt-PT" : "en";
  }, [lang]);

  const setLang = (l: Lang) => setLangState(l);
  const toggleLang = () => setLangState((l) => (l === "pt" ? "en" : "pt"));

  return (
    <I18nContext.Provider value={{ lang, setLang, toggleLang }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => useContext(I18nContext);

/**
 * Local per-component copy helper.
 * Usage:
 *   const c = useCopy({ pt: { title: "Olá" }, en: { title: "Hello" } });
 *   <h1>{c.title}</h1>
 */
export function useCopy<T>(copy: Record<Lang, T>): T {
  const { lang } = useI18n();
  return copy[lang];
}
