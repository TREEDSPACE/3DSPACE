import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, User, Search } from "lucide-react";
import { CartDrawer } from "@/components/CartDrawer";
import { useAuth } from "@/hooks/useAuth";
import BrandLogo from "@/components/BrandLogo";
import { useCopy } from "@/i18n";
import { ThemeToggle, LangToggle } from "@/components/ThemeLangControls";
import SideNav from "@/components/SideNav";

const copy = {
  pt: {
    nav: [
      { label: "Início", path: "/" },
      { label: "Serviços", path: "/servicos" },
      { label: "Formação", path: "/formacao" },
      { label: "Produtos", path: "/produtos" },
      { label: "Sobre Nós", path: "/sobre" },
      { label: "Para Empresas", path: "/empresas" },
      { label: "Contacto", path: "/contacto" },
    ],
    search: "Pesquisar...",
    account: "Conta",
    login: "Entrar",
    accountMobile: "A Minha Conta",
    loginMobile: "Entrar / Registar",
  },
  en: {
    nav: [
      { label: "Home", path: "/" },
      { label: "Services", path: "/servicos" },
      { label: "Training", path: "/formacao" },
      { label: "Products", path: "/produtos" },
      { label: "About Us", path: "/sobre" },
      { label: "For Business", path: "/empresas" },
      { label: "Contact", path: "/contacto" },
    ],
    search: "Search...",
    account: "Account",
    login: "Sign in",
    accountMobile: "My Account",
    loginMobile: "Sign in / Register",
  },
};

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { user } = useAuth();
  const c = useCopy(copy);
  const navLinks = c.nav;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  useEffect(() => setMobileOpen(false), [location]);


  return (
    <header
      className={`brand-header fixed top-0 left-0 right-0 z-[60] transition-all duration-300 ${
        mobileOpen
          ? "bg-[hsl(var(--background))]"
          : scrolled
          ? "bg-background/95 backdrop-blur-md shadow-lg shadow-black/20"
          : "bg-transparent"
      }`}

    >
      <div className="hidden lg:flex items-center justify-between py-4">
        <Link to="/" className="flex items-center shrink-0 px-6">
          <BrandLogo className="w-40" />
        </Link>

        <div className="flex-1 flex justify-center px-6">
          <div className="w-full max-w-xl">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
              <input
                type="text"
                placeholder={c.search}
                className="w-full bg-background/60 border border-border/40 rounded-none py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[hsl(var(--brand-lime))]/60 focus:bg-background transition-colors"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 pl-4 xl:pl-6 border-l border-border/30 shrink-0">
            <Link
              to={user ? "/conta" : "/auth"}
              className="flex items-center gap-2 text-sm font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              <User size={18} />
              {user ? c.account : c.login}
            </Link>
            <CartDrawer />
            <div className="flex items-center gap-1">
              <ThemeToggle />
              <LangToggle />
            </div>
          </div>
        </div>

      {/* Mobile header */}
      <div className="container mx-auto flex lg:hidden items-center justify-between px-4 md:px-6 py-4">
        <Link to="/" className="flex items-center">
          <BrandLogo className="w-28 sm:w-40" />
        </Link>

        {/* Mobile: Cart + Toggle */}
        <div className="lg:hidden flex items-center gap-2">
          <CartDrawer />
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <LangToggle />
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="text-foreground p-2 min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Desktop side nav — fixed, follows scroll */}
      <SideNav />

      {/* Mobile Nav */}
      {mobileOpen && (
        <nav className="lg:hidden fixed inset-0 top-[72px] bg-[hsl(var(--background))] backdrop-blur-none px-6 pt-8 pb-6 z-[60] overflow-y-auto overscroll-contain">

          {navLinks.map((link) => {
            const isActive = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center justify-between py-4 text-lg font-medium uppercase tracking-wider transition-colors hover:text-foreground border-b border-border/30 ${
                  isActive ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                <span>{link.label}</span>
                {isActive && <span className="w-2 h-2 rounded-full bg-[hsl(var(--brand-lime))]" />}
              </Link>
            );
          })}
          <Link
            to={user ? "/conta" : "/auth"}
            className="flex items-center gap-3 py-4 text-lg font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground border-b border-border/30"
          >
            <User size={20} />
            <span>{user ? c.accountMobile : c.loginMobile}</span>
          </Link>
        </nav>

      )}
    </header>
  );
};

export default Header;
