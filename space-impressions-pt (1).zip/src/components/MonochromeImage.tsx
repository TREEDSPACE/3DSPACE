import { ImgHTMLAttributes } from "react";

interface MonochromeImageProps extends ImgHTMLAttributes<HTMLImageElement> {
  /** intensity of the B&W treatment */
  intensity?: "full" | "soft" | "none";
}

const MonochromeImage = ({ intensity = "full", className = "", ...rest }: MonochromeImageProps) => {
  const filter =
    intensity === "full"
      ? "grayscale contrast-110 brightness-95"
      : intensity === "soft"
      ? "grayscale-[60%] contrast-105"
      : "";
  return <img {...rest} className={`${filter} ${className}`} />;
};

export default MonochromeImage;
