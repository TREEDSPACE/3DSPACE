import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { useI18n } from "@/i18n";

export const ThemeToggle = ({ className = "" }: { className?: string }) => {
  const { theme, toggleTheme } = useTheme();
  const { lang } = useI18n();
  const label =
    theme === "dark"
      ? lang === "pt"
        ? "Ativar modo claro"
        : "Switch to light mode"
      : lang === "pt"
      ? "Ativar modo escuro"
      : "Switch to dark mode";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={label}
      title={label}
      className={`flex items-center justify-center min-h-[44px] min-w-[44px] rounded-full border border-border/60 text-muted-foreground hover:text-[hsl(var(--brand-lime))] hover:border-[hsl(var(--brand-lime))] transition-colors ${className}`}
    >
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
};

export const LangToggle = ({ className = "" }: { className?: string }) => {
  const { lang, toggleLang } = useI18n();
  const label = lang === "pt" ? "Switch to English" : "Mudar para Português";

  return (
    <button
      type="button"
      onClick={toggleLang}
      aria-label={label}
      title={label}
      className={`flex items-center justify-center gap-1 min-h-[44px] px-3 rounded-full border border-border/60 text-xs font-mono uppercase tracking-[0.15em] text-muted-foreground hover:text-[hsl(var(--brand-lime))] hover:border-[hsl(var(--brand-lime))] transition-colors ${className}`}
    >
      <span className={lang === "pt" ? "text-[hsl(var(--brand-lime))]" : ""}>PT</span>
      <span className="opacity-40">/</span>
      <span className={lang === "en" ? "text-[hsl(var(--brand-lime))]" : ""}>EN</span>
    </button>
  );
};
