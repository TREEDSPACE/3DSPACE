import { useState, useId } from "react";
import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { useCopy } from "@/i18n";

interface ServiceFlipCardProps {
  icon: LucideIcon;
  title: string;
  desc: string;
}

const copy = {
  pt: { tag: "// SERVIÇO" },
  en: { tag: "// SERVICE" },
};

const ServiceFlipCard = ({ icon: Icon, title, desc }: ServiceFlipCardProps) => {
  const c = useCopy(copy);
  const [flipped, setFlipped] = useState(false);
  const gridId = useId();

  const PagePeelCorner = ({ light = true }: { light?: boolean }) => (
    <div className="absolute bottom-3 right-3 w-8 h-8 overflow-hidden">
      <div
        className="absolute bottom-0 right-0 w-0 h-0"
        style={{
          borderStyle: "solid",
          borderWidth: "0 0 28px 28px",
          borderColor: `transparent transparent ${light ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.1)"} transparent`,
        }}
      />
      <div
        className="absolute bottom-0 right-0 w-0 h-0"
        style={{
          borderStyle: "solid",
          borderWidth: "0 0 24px 24px",
          borderColor: `transparent transparent ${light ? "#f0f0f0" : "rgba(255,255,255,0.05)"} transparent`,
        }}
      />
    </div>
  );

  return (
    <div
      className="cursor-pointer h-[320px] md:h-[360px]"
      style={{ perspective: "1000px" }}
      onClick={() => setFlipped(!flipped)}
    >
      <motion.div
        className="relative w-full h-full"
        style={{ transformStyle: "preserve-3d" }}
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 rounded-lg border border-black/10 bg-white flex flex-col items-center justify-center p-6 md:p-8 group hover:border-[hsl(var(--brand-lime))]/60 transition-colors"
          style={{ backfaceVisibility: "hidden" }}
        >
          <div className="absolute top-4 left-4 tech-mono text-black/40">{c.tag}</div>
          <Icon className="w-12 h-12 md:w-14 md:h-14 text-black mb-6 group-hover:text-[hsl(var(--brand-lime))] transition-colors" />
          <h3 className="font-heading font-semibold text-base md:text-lg uppercase tracking-wide text-black text-center">
            {title}
          </h3>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-8 h-px bg-[hsl(var(--brand-lime))] opacity-0 group-hover:opacity-100 transition-opacity" />
          <PagePeelCorner light />
        </div>

        {/* Back */}
        <div
          className="absolute inset-0 rounded-lg bg-[hsl(0,0%,7%)] overflow-hidden flex flex-col items-center justify-center p-6 md:p-8"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id={`card-grid-${gridId}`} width="30" height="30" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 30" fill="none" stroke="white" strokeWidth="0.5" opacity="0.1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill={`url(#card-grid-${gridId})`} />
          </svg>

          <div className="relative z-10 flex flex-col items-center text-center">
            <div className="w-8 h-px bg-[hsl(var(--brand-lime))] mb-4" />
            <p className="text-white/70 text-sm leading-relaxed">{desc}</p>
          </div>

          <PagePeelCorner light={false} />
        </div>
      </motion.div>
    </div>
  );
};

export default ServiceFlipCard;
