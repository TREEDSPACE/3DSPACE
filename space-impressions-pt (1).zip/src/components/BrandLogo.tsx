import horizontalInk from "@/assets/logo-2026-horizontal-ink.png.asset.json";
import horizontalLime from "@/assets/logo-2026-horizontal-lime.png.asset.json";
import stackedInk from "@/assets/logo-2026-stacked-ink.png.asset.json";
import stackedLime from "@/assets/logo-2026-stacked-lime.png.asset.json";
import symbolInk from "@/assets/logo-2026-symbol-ink.png.asset.json";
import symbolLime from "@/assets/logo-2026-symbol-lime.png.asset.json";

const variants = {
  horizontal: { ink: horizontalInk.url, lime: horizontalLime.url, ratio: "2798 / 504" },
  stacked: { ink: stackedInk.url, lime: stackedLime.url, ratio: "1293 / 1377" },
  symbol: { ink: symbolInk.url, lime: symbolLime.url, ratio: "1293 / 1091" },
};

/** Original PDF geometry, recoloured exclusively through existing theme tokens. */
const BrandLogo = ({ variant = "horizontal", className = "" }: {
  variant?: keyof typeof variants;
  className?: string;
}) => {
  const asset = variants[variant];
  return (
    <span role="img" aria-label="3D Space" className={`brand-mark relative inline-block shrink-0 ${className}`} style={{ aspectRatio: asset.ratio }}>
      <span className="absolute inset-0 bg-foreground" style={{ maskImage: `url("${asset.ink}")`, WebkitMaskImage: `url("${asset.ink}")`, maskSize: "contain", WebkitMaskSize: "contain", maskRepeat: "no-repeat", WebkitMaskRepeat: "no-repeat" }} />
      <span className="absolute inset-0 bg-brand-lime" style={{ maskImage: `url("${asset.lime}")`, WebkitMaskImage: `url("${asset.lime}")`, maskSize: "contain", WebkitMaskSize: "contain", maskRepeat: "no-repeat", WebkitMaskRepeat: "no-repeat" }} />
    </span>
  );
};

export default BrandLogo;