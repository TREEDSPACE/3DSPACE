// Desativado a pedido — o padrão de marca substitui os quadriculados em todo o site.
interface GridPatternProps {
  className?: string;
  accent?: "white" | "lime";
  size?: number;
  opacity?: number;
}
const GridPattern = (_props: GridPatternProps) => null;
export default GridPattern;

