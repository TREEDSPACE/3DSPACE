import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { GraduationCap, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

interface TrainingRegistration {
  id: string;
  course_level: string;
  format: string;
  preferred_start_date: string | null;
  message: string;
  status: string;
  created_at: string;
}

const levelLabels: Record<string, string> = {
  beginner: "Iniciado",
  intermediate: "Intermédio",
  advanced: "Avançado",
};

const statusLabels: Record<string, string> = {
  pending: "Por confirmar",
  confirmed: "Confirmada",
  completed: "Concluída",
  cancelled: "Cancelada",
};

const formatDate = (d: string | null) =>
  d ? new Date(`${d}T00:00:00`).toLocaleDateString("pt-PT", { day: "2-digit", month: "long", year: "numeric" }) : "Data a definir";

const TrainingsPanel = () => {
  const [items, setItems] = useState<TrainingRegistration[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase
      .from("training_registrations" as any)
      .select("id, course_level, format, preferred_start_date, message, status, created_at")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (!active) return;
        if (error) toast.error("Não foi possível carregar as formações");
        setItems(((data as unknown) as TrainingRegistration[]) ?? []);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="py-12 text-center">
        <GraduationCap className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">Ainda não se inscreveu em nenhuma formação.</p>
        <Button asChild className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
          <Link to="/formacao">Ver formações</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.id} className="border border-border/40 rounded-lg p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-heading uppercase tracking-wide text-sm">{levelLabels[item.course_level] ?? item.course_level}</p>
              <p className="text-xs text-muted-foreground tech-mono mt-1">
                {formatDate(item.preferred_start_date)} · {item.format === "online" ? "Online" : item.format}
              </p>
            </div>
            <Badge variant="outline" className="uppercase tracking-wider text-[10px]">
              {statusLabels[item.status] ?? item.status}
            </Badge>
          </div>
          <p className="mt-3 text-sm text-muted-foreground whitespace-pre-line">{item.message}</p>
        </div>
      ))}
      <Button asChild variant="outline" className="uppercase tracking-wider font-heading min-h-[48px]">
        <Link to="/formacao">Inscrever-me noutra formação</Link>
      </Button>
    </div>
  );
};

export default TrainingsPanel;
