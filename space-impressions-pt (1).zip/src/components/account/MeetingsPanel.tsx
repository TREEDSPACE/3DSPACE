import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Video, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { platformLabels } from "@/pages/Reuniao";

interface Meeting {
  id: string;
  project_type: string | null;
  description: string;
  platform: string;
  preferred_date: string;
  preferred_time: string;
  alternative_date: string | null;
  alternative_time: string | null;
  status: string;
  meeting_url: string | null;
  created_at: string;
}

const statusLabels: Record<string, string> = {
  pendente: "Por confirmar",
  confirmada: "Confirmada",
  realizada: "Realizada",
  cancelada: "Cancelada",
};

const formatDate = (d: string) =>
  new Date(`${d}T00:00:00`).toLocaleDateString("pt-PT", { day: "2-digit", month: "long", year: "numeric" });

const MeetingsPanel = () => {
  const [items, setItems] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase
      .from("meeting_requests")
      .select("id, project_type, description, platform, preferred_date, preferred_time, alternative_date, alternative_time, status, meeting_url, created_at")
      .order("preferred_date", { ascending: false })
      .then(({ data, error }) => {
        if (!active) return;
        if (error) toast.error("Não foi possível carregar as reuniões");
        setItems((data as Meeting[]) ?? []);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="py-12 text-center">
        <Video className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">Ainda não marcou nenhuma videochamada.</p>
        <Button asChild className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
          <Link to="/marcar-reuniao">Marcar reunião</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {items.map((m) => (
        <div key={m.id} className="border border-border/40 rounded-lg p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-heading uppercase tracking-wide text-sm">{m.project_type || "Videochamada técnica"}</p>
              <p className="text-xs text-muted-foreground tech-mono mt-1">
                {formatDate(m.preferred_date)} · {m.preferred_time} · {platformLabels[m.platform] ?? m.platform}
              </p>
              {m.alternative_date && (
                <p className="text-xs text-muted-foreground mt-1">
                  Alternativa: {formatDate(m.alternative_date)} {m.alternative_time ? `· ${m.alternative_time}` : ""}
                </p>
              )}
            </div>
            <Badge variant="outline" className="uppercase tracking-wider text-[10px]">
              {statusLabels[m.status] ?? m.status}
            </Badge>
          </div>
          <p className="mt-3 text-sm text-muted-foreground whitespace-pre-line">{m.description}</p>
          {m.meeting_url && (
            <a
              href={m.meeting_url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-sm text-[hsl(var(--brand-lime))] hover:underline min-h-[44px]"
            >
              Entrar na reunião <ExternalLink className="h-3 w-3" />
            </a>
          )}
        </div>
      ))}
      <Button asChild variant="outline" className="uppercase tracking-wider font-heading min-h-[48px]">
        <Link to="/marcar-reuniao">Marcar nova reunião</Link>
      </Button>
    </div>
  );
};

export default MeetingsPanel;
