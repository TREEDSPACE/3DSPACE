import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ExternalLink, Loader2, Package, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/shopify";

interface OrderItem {
  title: string;
  variantTitle: string | null;
  quantity: number;
  total: string;
  currency: string;
  image: string | null;
}

interface ShopifyOrder {
  id: string;
  name: string;
  createdAt: string;
  financialStatus: string | null;
  fulfillmentStatus: string | null;
  statusUrl: string | null;
  total: string;
  currency: string;
  tracking: { number: string | null; url: string | null; company: string | null }[];
  items: OrderItem[];
}

const financialLabels: Record<string, string> = {
  PAID: "Pago",
  PENDING: "Pagamento pendente",
  REFUNDED: "Reembolsado",
  PARTIALLY_REFUNDED: "Parcialmente reembolsado",
  VOIDED: "Anulado",
  AUTHORIZED: "Autorizado",
};

const fulfillmentLabels: Record<string, string> = {
  FULFILLED: "Enviado",
  UNFULFILLED: "Em processamento",
  PARTIALLY_FULFILLED: "Parcialmente enviado",
  IN_PROGRESS: "Em preparação",
  SCHEDULED: "Agendado",
  ON_HOLD: "Em espera",
  RESTOCKED: "Devolvido a stock",
};

const isCurrent = (o: ShopifyOrder) =>
  o.fulfillmentStatus !== "FULFILLED" && o.fulfillmentStatus !== "RESTOCKED";

const OrderCard = ({ order }: { order: ShopifyOrder }) => (
  <div className="border border-border/40 rounded-lg p-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <p className="font-heading uppercase tracking-wide">Encomenda {order.name}</p>
        <p className="text-xs text-muted-foreground tech-mono">
          {new Date(order.createdAt).toLocaleDateString("pt-PT", { day: "2-digit", month: "long", year: "numeric" })}
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        {order.fulfillmentStatus && (
          <Badge variant="outline" className="uppercase tracking-wider text-[10px]">
            {fulfillmentLabels[order.fulfillmentStatus] ?? order.fulfillmentStatus}
          </Badge>
        )}
        {order.financialStatus && (
          <Badge className="uppercase tracking-wider text-[10px]">
            {financialLabels[order.financialStatus] ?? order.financialStatus}
          </Badge>
        )}
      </div>
    </div>

    <div className="mt-4 space-y-3">
      {order.items.map((item, idx) => (
        <div key={idx} className="flex items-center gap-3">
          <div className="h-12 w-12 rounded bg-secondary overflow-hidden flex-shrink-0">
            {item.image && <img src={item.image} alt={item.title} className="h-full w-full object-cover" loading="lazy" />}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm truncate">{item.title}</p>
            {item.variantTitle && <p className="text-xs text-muted-foreground">{item.variantTitle}</p>}
          </div>
          <span className="text-xs text-muted-foreground tech-mono">x{item.quantity}</span>
          <span className="text-sm">{formatPrice(item.total, item.currency)}</span>
        </div>
      ))}
    </div>

    {order.tracking.filter((t) => t.url || t.number).length > 0 && (
      <div className="mt-4 space-y-1">
        {order.tracking.map((t, i) => (
          <p key={i} className="text-xs text-muted-foreground flex items-center gap-2">
            <Truck className="h-3 w-3" />
            {t.company ?? "Envio"} {t.number}
            {t.url && (
              <a href={t.url} target="_blank" rel="noopener noreferrer" className="text-[hsl(var(--brand-lime))] underline underline-offset-4">
                seguir
              </a>
            )}
          </p>
        ))}
      </div>
    )}

    <div className="mt-4 pt-4 border-t border-border/40 flex flex-wrap items-center justify-between gap-3">
      <span className="font-heading uppercase tracking-wide">Total {formatPrice(order.total, order.currency)}</span>
      {order.statusUrl && (
        <Button asChild variant="outline" size="sm" className="uppercase tracking-wider font-heading">
          <a href={order.statusUrl} target="_blank" rel="noopener noreferrer">
            Detalhes <ExternalLink className="ml-2 h-3 w-3" />
          </a>
        </Button>
      )}
    </div>
  </div>
);

const OrdersPanel = ({ history = false }: { history?: boolean }) => {
  const [orders, setOrders] = useState<ShopifyOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [warning, setWarning] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    supabase.functions
      .invoke("shopify-orders")
      .then(({ data, error }) => {
        if (!active) return;
        if (error) {
          setWarning("unavailable");
        } else {
          setOrders(data?.orders ?? []);
          setWarning(data?.warning ?? null);
        }
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const list = history ? orders.filter((o) => !isCurrent(o)) : orders.filter(isCurrent);

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  if (warning) {
    return (
      <p className="py-10 text-sm text-muted-foreground">
        Não foi possível carregar as encomendas neste momento. Tente novamente mais tarde ou contacte-nos.
      </p>
    );
  }

  if (list.length === 0) {
    return (
      <div className="py-12 text-center">
        <Package className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">
          {history ? "Ainda não tem encomendas concluídas." : "Não tem encomendas em curso."}
        </p>
        <Button asChild className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
          <Link to="/produtos">Ver produtos</Link>
        </Button>
      </div>
    );
  }

  return <div className="space-y-4">{list.map((o) => <OrderCard key={o.id} order={o} />)}</div>;
};

export default OrdersPanel;
