import { useEffect, useState } from "react";
import { z } from "zod";
import { Loader2, MapPin, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface Address {
  id: string;
  label: string | null;
  full_name: string;
  phone: string | null;
  address: string;
  postal_code: string;
  city: string;
  country: string;
  is_default: boolean;
}

const schema = z.object({
  label: z.string().trim().max(60).optional(),
  full_name: z.string().trim().min(2, { message: "Indique o destinatário" }).max(100),
  phone: z.string().trim().max(30).optional(),
  address: z.string().trim().min(3, { message: "Morada é obrigatória" }).max(200),
  postal_code: z.string().trim().min(3, { message: "Código postal é obrigatório" }).max(20),
  city: z.string().trim().min(2, { message: "Localidade é obrigatória" }).max(100),
  country: z.string().trim().min(2, { message: "País é obrigatório" }).max(100),
});

const emptyForm = { label: "", full_name: "", phone: "", address: "", postal_code: "", city: "", country: "Portugal" };

const AddressesPanel = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const refresh = async () => {
    const { data, error } = await supabase
      .from("addresses")
      .select("id, label, full_name, phone, address, postal_code, city, country, is_default")
      .order("is_default", { ascending: false })
      .order("created_at", { ascending: false });
    if (error) toast.error("Não foi possível carregar as moradas");
    setItems((data as Address[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("addresses").insert({
      user_id: user.id,
      label: parsed.data.label ?? null,
      full_name: parsed.data.full_name,
      phone: parsed.data.phone ?? null,
      address: parsed.data.address,
      postal_code: parsed.data.postal_code,
      city: parsed.data.city,
      country: parsed.data.country,
      is_default: items.length === 0,
    });

    setSaving(false);
    if (error) {
      toast.error("Não foi possível guardar a morada");
      return;
    }
    toast.success("Morada adicionada");
    setForm(emptyForm);
    setAdding(false);
    refresh();
  };

  const makeDefault = async (id: string) => {
    if (!user) return;
    await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id);
    await supabase.from("addresses").update({ is_default: true }).eq("id", id);
    refresh();
  };

  const remove = async (id: string) => {
    await supabase.from("addresses").delete().eq("id", id);
    toast.success("Morada removida");
    refresh();
  };

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {items.length === 0 && !adding && (
        <div className="py-10 text-center">
          <MapPin className="h-10 w-10 mx-auto text-muted-foreground" />
          <p className="mt-4 text-muted-foreground">Ainda não guardou nenhuma morada de entrega.</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {items.map((a) => (
          <div key={a.id} className="border border-border/40 rounded-lg p-5">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-heading uppercase tracking-wide text-sm">{a.label || "Morada"}</p>
                {a.is_default && (
                  <span className="tech-mono text-[10px] uppercase text-[hsl(var(--brand-lime))]">Predefinida</span>
                )}
              </div>
              <Button variant="ghost" size="icon" onClick={() => remove(a.id)} aria-label="Remover morada">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-3 text-sm text-muted-foreground space-y-1">
              <p className="text-foreground">{a.full_name}</p>
              <p>{a.address}</p>
              <p>{a.postal_code} {a.city}</p>
              <p>{a.country}</p>
              {a.phone && <p>{a.phone}</p>}
            </div>
            {!a.is_default && (
              <Button variant="outline" size="sm" className="mt-4 uppercase tracking-wider font-heading" onClick={() => makeDefault(a.id)}>
                <Star className="mr-2 h-3 w-3" /> Definir como predefinida
              </Button>
            )}
          </div>
        ))}
      </div>

      {adding ? (
        <form onSubmit={handleAdd} className="border border-border/40 rounded-lg p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="a_label">Etiqueta (ex.: Casa, Escritório)</Label>
            <Input id="a_label" value={form.label} onChange={set("label")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a_name">Destinatário</Label>
            <Input id="a_name" value={form.full_name} onChange={set("full_name")} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a_phone">Telefone</Label>
            <Input id="a_phone" value={form.phone} onChange={set("phone")} />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="a_address">Morada</Label>
            <Input id="a_address" value={form.address} onChange={set("address")} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a_zip">Código postal</Label>
            <Input id="a_zip" value={form.postal_code} onChange={set("postal_code")} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a_city">Localidade</Label>
            <Input id="a_city" value={form.city} onChange={set("city")} required />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="a_country">País</Label>
            <Input id="a_country" value={form.country} onChange={set("country")} required />
          </div>
          <div className="sm:col-span-2 flex gap-3">
            <Button type="submit" disabled={saving} className="uppercase tracking-wider font-heading min-h-[48px]">
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Guardar morada
            </Button>
            <Button type="button" variant="outline" onClick={() => setAdding(false)} className="uppercase tracking-wider font-heading min-h-[48px]">
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <Button onClick={() => setAdding(true)} className="uppercase tracking-wider font-heading min-h-[48px]">
          <Plus className="mr-2 h-4 w-4" /> Adicionar morada
        </Button>
      )}
    </div>
  );
};

export default AddressesPanel;
