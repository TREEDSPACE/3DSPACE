import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

interface Quote {
  id: string;
  service: string | null;
  message: string;
  status: string;
  created_at: string;
}

const statusLabels: Record<string, string> = {
  novo: "Recebido",
  em_analise: "Em análise",
  respondido: "Respondido",
  fechado: "Fechado",
};

const QuotesPanel = () => {
  const [items, setItems] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase
      .from("quote_requests")
      .select("id, service, message, status, created_at")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (!active) return;
        if (error) toast.error("Não foi possível carregar os pedidos de orçamento");
        setItems((data as Quote[]) ?? []);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="py-12 text-center">
        <FileText className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">Ainda não submeteu pedidos de orçamento.</p>
        <Button asChild className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
          <Link to="/contacto">Pedir orçamento</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {items.map((q) => (
        <div key={q.id} className="border border-border/40 rounded-lg p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-heading uppercase tracking-wide text-sm">{q.service || "Pedido de orçamento"}</p>
              <p className="text-xs text-muted-foreground tech-mono">
                {new Date(q.created_at).toLocaleDateString("pt-PT", { day: "2-digit", month: "long", year: "numeric" })}
              </p>
            </div>
            <Badge variant="outline" className="uppercase tracking-wider text-[10px]">
              {statusLabels[q.status] ?? q.status}
            </Badge>
          </div>
          <p className="mt-3 text-sm text-muted-foreground whitespace-pre-line">{q.message}</p>
        </div>
      ))}
    </div>
  );
};

export default QuotesPanel;
