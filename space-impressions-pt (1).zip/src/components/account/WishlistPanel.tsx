import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Heart, Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWishlistStore } from "@/stores/wishlistStore";
import { formatPrice } from "@/lib/shopify";

const WishlistPanel = () => {
  const { items, loading, loaded, load, remove } = useWishlistStore();

  useEffect(() => {
    if (!loaded) load();
  }, [loaded, load]);

  if (loading || !loaded) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-[hsl(var(--brand-lime))]" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="py-12 text-center">
        <Heart className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">Ainda não guardou produtos nos favoritos.</p>
        <Button asChild className="mt-6 uppercase tracking-wider font-heading min-h-[48px]">
          <Link to="/produtos">Explorar produtos</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {items.map((item) => (
        <div key={item.id} className="border border-border/40 rounded-lg p-4 flex gap-4 items-center">
          <div className="h-16 w-16 rounded bg-secondary overflow-hidden flex-shrink-0">
            {item.image_url && <img src={item.image_url} alt={item.title} className="h-full w-full object-cover" loading="lazy" />}
          </div>
          <div className="min-w-0 flex-1">
            <Link to={`/produto/${item.product_handle}`} className="text-sm font-medium hover:text-[hsl(var(--brand-lime))] line-clamp-2">
              {item.title}
            </Link>
            {item.price != null && (
              <p className="text-sm text-muted-foreground mt-1">
                {formatPrice(String(item.price), item.currency ?? "EUR")}
              </p>
            )}
          </div>
          <Button variant="ghost" size="icon" aria-label="Remover dos favoritos" onClick={() => remove(item.product_handle)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  );
};

export default WishlistPanel;
