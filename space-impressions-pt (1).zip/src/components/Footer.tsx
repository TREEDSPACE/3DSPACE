import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import { useCopy } from "@/i18n";

const copy = {
  pt: {
    tagline: "Transformamos ideias em realidade através da impressão 3D. Soluções personalizadas para particulares e empresas.",
    nav: "Navegação",
    services: "Serviços",
    contact: "Contacto",
    links: [
      { label: "Início", path: "/" },
      { label: "Serviços", path: "/servicos" },
      { label: "Formação", path: "/formacao" },
      { label: "Produtos", path: "/produtos" },
      { label: "Sobre Nós", path: "/sobre" },
      { label: "Contacto", path: "/contacto" },
    ],
    serviceList: ["Impressão 3D Personalizada", "Modelação 3D", "Prototipagem", "Formação em Impressão 3D", "Soluções Empresariais"],
    rights: "Todos os direitos reservados.",
    privacy: "Política de Privacidade",
    strap: "// FABRICAÇÃO ADITIVA / PT",
  },
  en: {
    tagline: "We turn ideas into reality through 3D printing. Custom solutions for individuals and businesses.",
    nav: "Navigation",
    services: "Services",
    contact: "Contact",
    links: [
      { label: "Home", path: "/" },
      { label: "Services", path: "/servicos" },
      { label: "Training", path: "/formacao" },
      { label: "Products", path: "/produtos" },
      { label: "About Us", path: "/sobre" },
      { label: "Contact", path: "/contacto" },
    ],
    serviceList: ["Custom 3D Printing", "3D Modelling", "Prototyping", "3D Printing Training", "Business Solutions"],
    rights: "All rights reserved.",
    privacy: "Privacy Policy",
    strap: "// ADDITIVE MANUFACTURING / PT",
  },
};

const Footer = () => {
  const c = useCopy(copy);
  return (
    <footer className="brand-footer relative bg-background">
      <div className="lime-hairline" />
      <div className="container mx-auto px-4 md:px-6 py-12 md:py-16">
        <div className="flex items-center justify-between mb-10">
          <span className="tech-mono text-foreground/50 hidden md:inline-flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[hsl(var(--brand-lime))] rounded-full" />
            // 3D.SPACE / EST. PORTUGAL
          </span>
          <span className="tech-mono text-foreground/50 hidden md:inline">@3D.SPACE_OFFICIAL</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center mb-4">
              <BrandLogo className="w-44" />
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {c.tagline}
            </p>
          </div>

          <div>
            <h4 className="font-heading font-semibold uppercase tracking-wider text-foreground mb-4 text-sm">{c.nav}</h4>
            <div className="flex flex-col gap-2">
              {c.links.map((link) => (
                <Link key={link.path} to={link.path} className="text-sm text-muted-foreground hover:text-[hsl(var(--brand-lime))] transition-colors py-1">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-heading font-semibold uppercase tracking-wider text-foreground mb-4 text-sm">{c.services}</h4>
            <div className="flex flex-col gap-2 text-sm text-muted-foreground">
              {c.serviceList.map((item) => (
                <span key={item}>{item}</span>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-heading font-semibold uppercase tracking-wider text-foreground mb-4 text-sm">{c.contact}</h4>
            <div className="flex flex-col gap-3 text-sm text-muted-foreground">
              <a href="mailto:geral.3dspace@gmail.com" className="flex items-center gap-2 hover:text-[hsl(var(--brand-lime))] transition-colors min-h-[44px]">
                <Mail size={14} className="text-[hsl(var(--brand-lime))]" /> geral.3dspace@gmail.com
              </a>
              <a href="tel:+351931060445" className="flex items-center gap-2 hover:text-[hsl(var(--brand-lime))] transition-colors min-h-[44px]">
                <Phone size={14} className="text-[hsl(var(--brand-lime))]" /> +351 931 060 445
              </a>
              <span className="flex items-center gap-2">
                <MapPin size={14} className="text-[hsl(var(--brand-lime))]" /> Lisboa, Portugal
              </span>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/40 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} 3D Space. {c.rights}</span>
          <div className="flex items-center gap-4">
            <Link to="/privacidade" className="hover:text-[hsl(var(--brand-lime))] transition-colors">{c.privacy}</Link>
            <span className="tech-mono">{c.strap}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
