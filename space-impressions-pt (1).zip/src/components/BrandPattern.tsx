import curveMask from "@/assets/logo-2026-pattern-full-ink.png.asset.json";
import strokesMask from "@/assets/logo-2026-pattern-full-lime.png.asset.json";
import { useTheme } from "@/hooks/useTheme";
import { useEffect, useRef, useState } from "react";

interface BrandPatternProps {
  className?: string;
  /** Reference symbol width in px */
  size?: number;
  opacity?: number;
  /** Fade direction of the gradient mask */
  fade?: "top" | "bottom" | "left" | "right" | "radial" | "none";
  /** "light" = white motif (dark surfaces) · "dark" = dark motif (light surfaces).
   *  If omitted, it auto-picks the tone that contrasts with the current theme. */
  tone?: "light" | "dark" | "auto";
}

const fadeMask: Record<string, string> = {
  top: "linear-gradient(to bottom, black, transparent 85%)",
  bottom: "linear-gradient(to top, black, transparent 85%)",
  left: "linear-gradient(to right, black, transparent 90%)",
  right: "linear-gradient(to left, black, transparent 90%)",
  radial: "radial-gradient(ellipse at center, black 15%, transparent 75%)",
  none: "none",
};

/** Ratio between the tile cell and the symbol drawn inside it.
 *  Everything above 1 is free space around each symbol, so motifs never touch. */
const TILE_RATIO = 1.55;
/** Symbol aspect ratio from the official PDF artwork (727 wide x 614 tall). */
const SYMBOL_ASPECT = 614 / 727;

/**
 * Tiled official brand symbol used as a subtle decorative texture behind
 * sections, faded with a gradient mask. Each motif sits in its own cell with
 * built-in breathing room, so symbols never collide. Every motif draws the
 * three strokes and the curve of the official artwork, both in one single
 * colour: white in dark mode, near-black in light mode.
 */
const BrandPattern = ({
  className = "",
  size = 160,
  opacity = 0.5,
  fade = "radial",
  tone = "auto",
}: BrandPatternProps) => {
  const { theme } = useTheme();
  const resolvedTone = tone === "auto" ? (theme === "dark" ? "light" : "dark") : tone;
  const toneClass = resolvedTone === "light" ? "brand-pattern-light" : "brand-pattern-dark";
  const mask = fadeMask[fade] ?? fadeMask.radial;

  const gridRef = useRef<HTMLDivElement>(null);
  const [dims, setDims] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const update = () => setDims({ w: el.offsetWidth, h: el.offsetHeight });
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const symW = Math.max(24, size * 0.55);
  const symH = symW * SYMBOL_ASPECT;
  const tile = symW * TILE_RATIO;

  // Oversized grid, rotated, so it always covers the container corners.
  const cover = 2;
  const cols = Math.ceil((dims.w * cover) / tile) + 1;
  const rows = Math.ceil((dims.h * cover) / tile) + 1;

  const cells: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      cells.push(
        <div
          key={`${r}-${c}`}
          style={{
            width: symW,
            height: symH,
            justifySelf: "center",
            alignSelf: "center",
            position: "relative",
          }}
        >
          {/* Strokes and curve are separate masks of the same artwork, drawn
              one over the other so the whole symbol reads in a single colour. */}
          {[strokesMask.url, curveMask.url].map((url) => (
            <div
              key={url}
              className="brand-pattern-ink absolute inset-0"
              style={{
                maskImage: `url("${url}")`,
                WebkitMaskImage: `url("${url}")`,
                maskSize: "100% 100%",
                WebkitMaskSize: "100% 100%",
                maskRepeat: "no-repeat",
                WebkitMaskRepeat: "no-repeat",
              }}
            />
          ))}
        </div>
      );
    }
  }

  return (
    <div
      aria-hidden
      className={`brand-pattern ${toneClass} absolute inset-0 pointer-events-none overflow-hidden ${className}`}
      style={{
        opacity,
        ...(mask !== "none"
          ? ({ maskImage: mask, WebkitMaskImage: mask } as React.CSSProperties)
          : {}),
      }}
    >
      <div
        ref={gridRef}
        className="absolute inset-0"
        style={{ overflow: "hidden" }}
      >
        <div
          className="absolute"
          style={{
            left: `${-50 * (cover - 1)}%`,
            top: `${-50 * (cover - 1)}%`,
            width: `${cover * 100}%`,
            height: `${cover * 100}%`,
            transform: "rotate(-30deg)",
            display: "grid",
            gridTemplateColumns: `repeat(${cols}, ${tile}px)`,
            gridAutoRows: `${tile}px`,
            justifyContent: "center",
            alignContent: "center",
          }}
        >
          {cells}
        </div>
      </div>
    </div>
  );
};

export default BrandPattern;
