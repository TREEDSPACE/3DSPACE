import { Link, useLocation } from "react-router-dom";
import { useCopy } from "@/i18n";

const copy = {
  pt: {
    nav: [
      { label: "Início", path: "/" },
      { label: "Serviços", path: "/servicos" },
      { label: "Formação", path: "/formacao" },
      { label: "Produtos", path: "/produtos" },
      { label: "Sobre Nós", path: "/sobre" },
      { label: "Para Empresas", path: "/empresas" },
      { label: "Contacto", path: "/contacto" },
    ],
  },
  en: {
    nav: [
      { label: "Home", path: "/" },
      { label: "Services", path: "/servicos" },
      { label: "Training", path: "/formacao" },
      { label: "Products", path: "/produtos" },
      { label: "About Us", path: "/sobre" },
      { label: "For Business", path: "/empresas" },
      { label: "Contact", path: "/contacto" },
    ],
  },
};

const SideNav = () => {
  const location = useLocation();
  const c = useCopy(copy);

  return (
    <nav
      aria-label="Main"
      className="brand-side-nav hidden lg:flex fixed left-0 top-[88px] xl:top-[96px] bottom-0 w-52 flex-col items-start px-6 py-8 z-50 bg-background/80 backdrop-blur-md border-r border-border/20"
    >
      {c.nav.map((link) => {
        const isActive = location.pathname === link.path;
        return (
          <Link
            key={link.path}
            to={link.path}
            className={`relative w-full pl-5 text-xs font-medium uppercase tracking-wider transition-colors hover:text-foreground group py-2.5 border-b border-border/10 ${
              isActive ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            {link.label}
            <span
              className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 h-4 bg-[hsl(var(--brand-lime))] transition-all duration-300 ${
                isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
              }`}
            />
          </Link>
        );
      })}
    </nav>
  );
};

export default SideNav;
