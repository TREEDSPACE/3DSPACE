import { useEffect } from "react";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { useWishlistStore, type WishlistInput } from "@/stores/wishlistStore";

interface WishlistButtonProps {
  product: WishlistInput;
  className?: string;
}

const WishlistButton = ({ product, className }: WishlistButtonProps) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { items, loaded, load, toggle } = useWishlistStore();
  const active = items.some((i) => i.product_handle === product.product_handle);

  useEffect(() => {
    if (user && !loaded) load();
  }, [user, loaded, load]);

  const handleClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast.error("Inicie sessão para guardar favoritos");
      navigate("/auth");
      return;
    }
    const result = await toggle(product);
    if (result === "error") toast.error("Não foi possível atualizar os favoritos");
    else if (result === "added") toast.success("Adicionado aos favoritos");
    else toast.success("Removido dos favoritos");
  };

  return (
    <button
      type="button"
      aria-label={active ? "Remover dos favoritos" : "Adicionar aos favoritos"}
      onClick={handleClick}
      className={cn(
        "inline-flex items-center justify-center h-10 w-10 rounded-full border border-border/50 bg-background/80 backdrop-blur transition-colors hover:border-[hsl(var(--brand-lime))]",
        className,
      )}
    >
      <Heart
        className={cn(
          "h-4 w-4 transition-colors",
          active ? "fill-[hsl(var(--brand-lime))] text-[hsl(var(--brand-lime))]" : "text-foreground",
        )}
      />
    </button>
  );
};

export default WishlistButton;
