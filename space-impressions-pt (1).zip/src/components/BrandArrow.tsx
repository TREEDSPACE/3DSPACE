interface BrandArrowProps {
  size?: number;
  className?: string;
  /** rotation in degrees, default 0 (down-right ↘) */
  rotate?: number;
  color?: "lime" | "white" | "black";
}

const colorMap = {
  lime: "hsl(var(--brand-lime))",
  white: "hsl(0 0% 98%)",
  black: "hsl(var(--brand-black))",
};

const BrandArrow = ({ size = 40, className = "", rotate = 0, color = "lime" }: BrandArrowProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    style={{ transform: `rotate(${rotate}deg)` }}
    aria-hidden="true"
  >
    <path
      d="M8 8 L32 32 M32 32 L32 18 M32 32 L18 32"
      stroke={colorMap[color]}
      strokeWidth="2.5"
      strokeLinecap="square"
      strokeLinejoin="miter"
    />
  </svg>
);

export default BrandArrow;
