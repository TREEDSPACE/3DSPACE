interface TechLabelProps {
  children: React.ReactNode;
  className?: string;
  position?: "absolute" | "static";
}

const TechLabel = ({ children, className = "", position = "absolute" }: TechLabelProps) => (
  <span
    className={`tech-mono text-foreground/60 hidden md:inline-flex items-center gap-2 ${
      position === "absolute" ? "absolute top-6 right-6 z-20" : ""
    } ${className}`}
  >
    <span className="w-1.5 h-1.5 bg-[hsl(var(--brand-lime))] rounded-full" />
    {children}
  </span>
);

export default TechLabel;
