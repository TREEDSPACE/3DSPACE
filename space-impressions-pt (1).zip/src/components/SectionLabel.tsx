interface SectionLabelProps {
  children: React.ReactNode;
  index?: string;
}

const SectionLabel = ({ children }: SectionLabelProps) => (
  <span className="label-tag mb-4">
    <span>{children}</span>
  </span>
);

export default SectionLabel;
