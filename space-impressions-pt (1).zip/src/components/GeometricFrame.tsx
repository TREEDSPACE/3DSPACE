import { ReactNode } from "react";

interface GeometricFrameProps {
  children: ReactNode;
  label?: string;
  className?: string;
  /** Highlight corners + label dot in lime */
  accent?: boolean;
}

const GeometricFrame = ({ children, label, className = "", accent = true }: GeometricFrameProps) => {
  const cornerColor = accent ? "border-[hsl(var(--brand-lime))]/70" : "border-foreground/25";
  return (
    <div className={`brand-geometric-frame relative ${className}`}>
      {/* Offset geometric frame behind */}
      <div className="absolute -top-3 -left-3 md:-top-4 md:-left-4 w-full h-full border border-foreground/15 rounded-lg" />
      <div className="absolute -bottom-3 -right-3 md:-bottom-4 md:-right-4 w-full h-full border border-foreground/10 rounded-lg" />

      {/* Corner accents */}
      <div className={`absolute -top-1.5 -left-1.5 md:-top-2 md:-left-2 w-4 h-4 md:w-5 md:h-5 border-t-2 border-l-2 ${cornerColor} rounded-tl`} />
      <div className={`absolute -bottom-1.5 -right-1.5 md:-bottom-2 md:-right-2 w-4 h-4 md:w-5 md:h-5 border-b-2 border-r-2 ${cornerColor} rounded-br`} />

      {/* Thin crossing lines */}
      <div className="absolute top-1/2 -left-6 md:-left-8 w-4 md:w-6 h-px bg-foreground/15" />
      <div className="absolute top-1/2 -right-6 md:-right-8 w-4 md:w-6 h-px bg-foreground/15" />
      <div className="absolute -top-6 md:-top-8 left-1/2 w-px h-4 md:h-6 bg-foreground/15" />
      <div className="absolute -bottom-6 md:-bottom-8 left-1/2 w-px h-4 md:h-6 bg-foreground/15" />

      {/* Main content */}
      <div className="relative z-10 overflow-hidden rounded-lg">{children}</div>

      {/* Technical label */}
      {label && (
        <div className="absolute -bottom-1 right-4 md:right-6 z-20 bg-background/90 backdrop-blur-sm px-2 py-0.5 md:px-3 md:py-1 inline-flex items-center gap-2">
          {accent && <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--brand-lime))]" />}
          <span className="text-[10px] md:text-xs font-mono uppercase tracking-widest text-foreground/60">{label}</span>
        </div>
      )}
    </div>
  );
};

export default GeometricFrame;
