export function PortugueseFlag({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 600 400"
      className={className}
      aria-label="Bandeira de Portugal"
      role="img"
    >
      <rect x="0" y="0" width="240" height="400" fill="#006600" />
      <rect x="240" y="0" width="360" height="400" fill="#FF0000" />
      <circle cx="260" cy="200" r="70" fill="#FFFF00" />
      <circle cx="260" cy="200" r="55" fill="#FF0000" stroke="#FFFFFF" strokeWidth="6" />
      <path d="M260 155 L270 185 H300 L275 205 L285 235 L260 215 L235 235 L245 205 H220 L250 185 Z" fill="#FFFFFF" />
    </svg>
  );
}
