import { create } from "zustand";
import { supabase } from "@/integrations/supabase/client";

export interface WishlistItem {
  id: string;
  product_handle: string;
  product_id: string | null;
  title: string;
  image_url: string | null;
  price: number | null;
  currency: string | null;
}

export interface WishlistInput {
  product_handle: string;
  product_id?: string | null;
  title: string;
  image_url?: string | null;
  price?: number | null;
  currency?: string | null;
}

interface WishlistState {
  items: WishlistItem[];
  loading: boolean;
  loaded: boolean;
  load: () => Promise<void>;
  clearLocal: () => void;
  has: (handle: string) => boolean;
  toggle: (input: WishlistInput) => Promise<"added" | "removed" | "error">;
  remove: (handle: string) => Promise<void>;
}

export const useWishlistStore = create<WishlistState>((set, get) => ({
  items: [],
  loading: false,
  loaded: false,

  load: async () => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) {
      set({ items: [], loaded: true, loading: false });
      return;
    }
    set({ loading: true });
    const { data, error } = await supabase
      .from("wishlist_items")
      .select("id, product_handle, product_id, title, image_url, price, currency")
      .order("created_at", { ascending: false });
    set({ items: error ? [] : (data as WishlistItem[]), loading: false, loaded: true });
  },

  clearLocal: () => set({ items: [], loaded: false }),

  has: (handle) => get().items.some((i) => i.product_handle === handle),

  toggle: async (input) => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return "error";

    const existing = get().items.find((i) => i.product_handle === input.product_handle);
    if (existing) {
      const { error } = await supabase.from("wishlist_items").delete().eq("id", existing.id);
      if (error) return "error";
      set({ items: get().items.filter((i) => i.id !== existing.id) });
      return "removed";
    }

    const { data, error } = await supabase
      .from("wishlist_items")
      .insert({
        user_id: auth.user.id,
        product_handle: input.product_handle,
        product_id: input.product_id ?? null,
        title: input.title,
        image_url: input.image_url ?? null,
        price: input.price ?? null,
        currency: input.currency ?? "EUR",
      })
      .select("id, product_handle, product_id, title, image_url, price, currency")
      .single();
    if (error || !data) return "error";
    set({ items: [data as WishlistItem, ...get().items] });
    return "added";
  },

  remove: async (handle) => {
    const existing = get().items.find((i) => i.product_handle === handle);
    if (!existing) return;
    await supabase.from("wishlist_items").delete().eq("id", existing.id);
    set({ items: get().items.filter((i) => i.id !== existing.id) });
  },
}));
