import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useCartSync } from "@/hooks/useCartSync";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/hooks/useTheme";
import { I18nProvider } from "@/i18n";
import Index from "./pages/Index";
import Servicos from "./pages/Servicos";
import Produtos from "./pages/Produtos";
import ProductDetail from "./pages/ProductDetail";
import Sobre from "./pages/Sobre";
import Contacto from "./pages/Contacto";
import Empresas from "./pages/Empresas";
import Reuniao from "./pages/Reuniao";
import Formacao from "./pages/Formacao";

import Auth from "./pages/Auth";
import Conta from "./pages/Conta";
import ResetPassword from "./pages/ResetPassword";
import Privacidade from "./pages/Privacidade";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const AppRoutes = () => {
  useCartSync();
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/servicos" element={<Servicos />} />
      <Route path="/produtos" element={<Produtos />} />
      <Route path="/produto/:handle" element={<ProductDetail />} />
      <Route path="/sobre" element={<Sobre />} />
      <Route path="/contacto" element={<Contacto />} />
      <Route path="/empresas" element={<Empresas />} />
      <Route path="/marcar-reuniao" element={<Reuniao />} />
      <Route path="/formacao" element={<Formacao />} />

      <Route path="/auth" element={<Auth />} />
      <Route path="/conta" element={<Conta />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/privacidade" element={<Privacidade />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ThemeProvider>
      <I18nProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </I18nProvider>
    </ThemeProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
