# Architecture rules

- Render the official logo family through BrandLogo using extracted PDF alpha masks and semantic theme tokens; this preserves artwork geometry and keeps both themes legible.
- Keep brand surface treatments in global CSS and BrandPattern so cosmetic updates remain consistent without changing page layouts or business behaviour.
- Keep Shopify handoff code separate from the running React app and use native Liquid commerce resources; export requests must not alter the connected store.